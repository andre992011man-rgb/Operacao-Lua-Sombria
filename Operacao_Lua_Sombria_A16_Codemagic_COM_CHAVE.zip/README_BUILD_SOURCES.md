# Fontes oficiais usadas no build

- Godot 4.7.2 estável: https://godotengine.org/download/archive/4.7.2-stable/
- Godot Gradle Android: https://docs.godotengine.org/en/4.7/tutorials/export/android_gradle_build.html
- Godot Android plugins: https://docs.godotengine.org/en/4.7/tutorials/platform/android/android_plugin.html
- Android command-line tools / SDK: https://developer.android.com/tools
- Android Build Tools: https://developer.android.com/tools/releases/build-tools
- GitHub Actions: https://docs.github.com/en/actions/concepts/billing-and-usage
