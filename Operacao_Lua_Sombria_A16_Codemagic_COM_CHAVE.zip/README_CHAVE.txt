PACOTE OPERACAO LUA SOMBRIA + CHAVE DE ASSINATURA

Este pacote contem o projeto e a chave JKS para configurar a assinatura Android no Codemagic.

CONFIGURACAO NO CODEMAGIC:
1. Team settings -> codemagic.yaml settings -> Code signing identities -> Android keystores.
2. Envie: SIGNING_PRIVATE_DO_NOT_UPLOAD/lua_sombria_release.jks
3. Reference name: lua_sombria_release
4. Key alias: lua_sombria
5. Use as senhas fornecidas separadamente.

ATENCAO:
A chave privada NAO deve ser enviada ao GitHub, principalmente em repositorio publico.
O codemagic.yaml ja referencia lua_sombria_release no workflow de assinatura.
