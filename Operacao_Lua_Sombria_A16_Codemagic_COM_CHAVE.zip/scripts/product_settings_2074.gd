class_name ProductSettings2074
extends Node
## Configurações persistentes de produto para Android/A16.
signal changed
const PATH := "user://product_settings_2074.json"
var master_volume := 0.85
var music_volume := 0.75
var sfx_volume := 0.90
var vibration := true
var battery_saver := false
var auto_quality := true
var subtitles := true
var hud_scale := 1.0
var sensitivity := 1.0
var show_fps := false
var language := "pt-BR"

func _ready(): load_settings()
func load_settings():
    if not FileAccess.file_exists(PATH): return
    var f=FileAccess.open(PATH,FileAccess.READ); if not f:return
    var d=JSON.parse_string(f.get_as_text()); f.close()
    if typeof(d)!=TYPE_DICTIONARY:return
    master_volume=float(d.get("master_volume",master_volume)); music_volume=float(d.get("music_volume",music_volume)); sfx_volume=float(d.get("sfx_volume",sfx_volume))
    vibration=bool(d.get("vibration",vibration)); battery_saver=bool(d.get("battery_saver",battery_saver)); auto_quality=bool(d.get("auto_quality",auto_quality)); subtitles=bool(d.get("subtitles",subtitles))
    hud_scale=float(d.get("hud_scale",hud_scale)); sensitivity=float(d.get("sensitivity",sensitivity)); show_fps=bool(d.get("show_fps",show_fps)); language=str(d.get("language",language))
func save_settings():
    var f=FileAccess.open(PATH,FileAccess.WRITE)
    if f:f.store_string(JSON.stringify(to_dict()))
    changed.emit()
func to_dict(): return {"version":1,"master_volume":master_volume,"music_volume":music_volume,"sfx_volume":sfx_volume,"vibration":vibration,"battery_saver":battery_saver,"auto_quality":auto_quality,"subtitles":subtitles,"hud_scale":hud_scale,"sensitivity":sensitivity,"show_fps":show_fps,"language":language}
func toggle_battery_saver(): battery_saver=not battery_saver; save_settings()
func toggle_vibration(): vibration=not vibration; save_settings()
func set_hud_scale(v): hud_scale=clamp(float(v),0.85,1.25); save_settings()
func set_sensitivity(v): sensitivity=clamp(float(v),0.5,2.0); save_settings()
