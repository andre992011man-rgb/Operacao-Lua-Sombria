extends Node3D

const MISSION_COUNT:=100
const REGIONS:=['Cidade Lua','Cidade Nova','Porto Velho','Vila Sombria','Vale Verde','Serra Negra','Base Militar','Complexo Lua','Centro Espacial','Órbita','Lua','Marte','Mercúrio','Vênus','Júpiter','Europa','Ganimedes','Saturno','Titã','Urano','Netuno','Tritão','Plutão']
const MISSIONS:=['Primeiro Sinal','A Mensagem','Rua Escura','O Depósito','Testemunha','Perseguição','O Primeiro Inimigo','Cidade em Alerta','O Arquivo','Estrada para o Norte','Hospital Santa Helena','Paciente 17','Subsolo','Apagão','Perseguição no Centro','Estação','O Trem','A Lista','Fuga de Cidade Nova','A Estrada de Terra','Casas Vazias','O Bar','O Cemitério','A Fazenda','Celeiro','A Floresta','O Acampamento','Voz no Rádio','O Último Morador','Rumo ao Rio','As Docas','Armazém 7','Contrabando','Ponte','Perseguição Fluvial','Estação de Água','Túnel','O Farol','Tempestade','Estradas Rurais','A Fazenda','O Silêncio','O Lago','O Moinho','A Plantação','A Noite','O Celeiro Vermelho','Emboscada','O Caminho para a Montanha','Subida','A Cabana','Mina Abandonada','Túneis','A Torre','Transmissão','O Acampamento','A Caverna','A Antena','O Complexo','Infiltração','Torre de Vigilância','Quartel','Garagem','Centro de Comando','Laboratório','Gerador','Heliponto','Bunker','O Arquivo Lua','Complexo Subterrâneo','Câmara Central','Último Confronto','Lua Sombria','Centro Espacial','Primeiro Lançamento','Estação Orbital','O Sinal','Primeira Viagem','Cidade Lunar','Base Lunar 01','O Laboratório','Mina Lunar','Complexo Subterrâneo','Chegada a Marte','Cidade Marciana','Colônia Perdida','O Deserto Vermelho','Base Subterrânea','O Sinal Marciano','Cidade Solaris','Cidade Nuvem','Estação Joviana','Europa','Ganimedes','Cidade Saturno','Titã','Estação Urano','Cidade Netuno','Tritão','Colônia Horizonte']

var state:GameState; var perf:PerformanceManager; var builder:WorldBuilder; var missions:MissionManager; var scanner:ScannerSystem; var drone:DroneSystem
var dialogue:DialogueSystem; var player:CharacterBody3D;
var device_profile:DeviceProfile; var traffic:TrafficSystem; var routines:NPCRoutineSystem; var ai_director:AIDirector; var shops:ShopSystem; var upgrades:UpgradeSystem; var sectors:SectorStreaming2074; var qa:QATelemetry; var camera:Camera3D; var pivot:Node3D
var enemies:Array[CharacterBody3D]=[]; var npcs:Array[CharacterBody3D]=[]; var vehicles:Array[VehicleController]=[]
var current_speed:=5.0; var sprinting:=false; var firing_cooldown:=0.0; var ui_info:Label; var objective_label:Label; var status_label:Label; var touch_stick_center:=Vector2.ZERO; var touch_stick:=Vector2.ZERO
var vehicle:VehicleController; var drone_model:Node3D; var active_interior_model:Node3D; var scanner_text:='Scanner pronto'; var interaction_cooldown:=0.0; var interior:=false; var interior_anchor:=Vector3.ZERO
var city_lua:CidadeLua2074; var access_cards:AccessCardSystem; var intro:IntroCinematic2074; var animation_controller:YABAAnimationController2074; var city_flow:CidadeLuaMissionFlow; var product_settings:ProductSettings2074; var value_graph:ValorGraph2074
var settings_panel:Panel
var hud_layer:CanvasLayer
var combat:CombatSystem2074; var police_ai:PoliceAI2074; var city_life:CityLifeDirector2074; var interiors:InteriorManager2074; var services:CityLuaServices2074; var cinematic:CityLuaCinematic2074; var mission_runtime:CityLuaMissionRuntime2074; var police_units:Array[Node3D]=[]
var completion:CompletionDirectorV10; var experience:ExperienceDirector2074
var android_services:AndroidServices2074; var content_cache:ContentCache2074; var updater:UpdateManager2074; var save_recovery:SaveRecovery2074; var diagnostics:AndroidDiagnostics2074; var final_android:FinalAndroidRuntime2074; var sdk_runtime:GameSdkRuntime2074; var modern_android:ModernAndroidRuntime2074; var android_feature_router:AndroidFeatureRouter2074

func _ready():
    android_services=AndroidServices2074.new(); add_child(android_services)
    content_cache=ContentCache2074.new(); add_child(content_cache)
    updater=UpdateManager2074.new(); add_child(updater)
    save_recovery=SaveRecovery2074.new(); add_child(save_recovery)
    diagnostics=AndroidDiagnostics2074.new(); add_child(diagnostics)
    final_android=FinalAndroidRuntime2074.new(); add_child(final_android)
    sdk_runtime=GameSdkRuntime2074.new(); add_child(sdk_runtime); sdk_runtime.boot()
    modern_android=ModernAndroidRuntime2074.new(); add_child(modern_android)
    android_feature_router=AndroidFeatureRouter2074.new(); add_child(android_feature_router)
    android_feature_router.emit_game_event("game_boot", {"build":"0.6.2074"})
    modern_android.performance_state_changed.connect(func(mode): dialogue.show_line("ANDROID", "Perfil de desempenho: %s" % mode) if dialogue else null)
    state=GameState.new(); add_child(state); state.load_game()
    experience=ExperienceDirector2074.new(); add_child(experience)
    perf=PerformanceManager.new(); add_child(perf)
    builder=WorldBuilder.new(); builder.name='WorldBuilder'; add_child(builder)
    missions=MissionManager.new(); add_child(missions); missions.load_data(); missions.start(state.mission_index+1)
    scanner=ScannerSystem.new(); add_child(scanner)
    drone=DroneSystem.new(); drone.name='ScoutDrone'; add_child(drone)
    dialogue=DialogueSystem.new(); add_child(dialogue)
    device_profile=DeviceProfile.new(); add_child(device_profile); device_profile.configure_from_profile('Galaxy A16')
    traffic=TrafficSystem.new(); add_child(traffic); traffic.setup(6)
    routines=NPCRoutineSystem.new(); add_child(routines)
    ai_director=AIDirector.new(); add_child(ai_director); ai_director.threat_level_changed.connect(func(level): dialogue.show_line('IA 2074','Nível de ameaça %d' % level))
    shops=ShopSystem.new(); add_child(shops)
    upgrades=UpgradeSystem.new(); add_child(upgrades)
    sectors=SectorStreaming2074.new(); add_child(sectors)
    qa=QATelemetry.new(); add_child(qa)
    access_cards=AccessCardSystem.new(); add_child(access_cards); access_cards.setup(state)
    city_flow=CidadeLuaMissionFlow.new(); add_child(city_flow); city_flow.setup(state,dialogue,access_cards)
    combat=CombatSystem2074.new(); add_child(combat); combat.hit_confirmed.connect(func(target,damage): dialogue.show_line('COMBATE','Impacto confirmado: %d' % damage)); combat.kill_confirmed.connect(func(target,damage): experience.register_kill())
    police_ai=PoliceAI2074.new(); add_child(police_ai);
    city_life=CityLifeDirector2074.new(); add_child(city_life); city_life.city_event.connect(func(t): dialogue.show_line('CIDADE LUA',t)); police_ai.alert_level_changed.connect(func(level): dialogue.show_line('POLÍCIA','Nível de alerta %d' % level))
    interiors=InteriorManager2074.new(); add_child(interiors)
    services=CityLuaServices2074.new(); add_child(services); services.setup(state,shops,upgrades); services.service_message.connect(func(t): dialogue.show_line('SERVIÇO',t))
    cinematic=CityLuaCinematic2074.new(); add_child(cinematic)
    mission_runtime=CityLuaMissionRuntime2074.new(); add_child(mission_runtime); mission_runtime.setup(state,dialogue)
    intro=IntroCinematic2074.new(); add_child(intro)
    _build_player(); experience.setup(state,player); _build_camera(); product_settings=ProductSettings2074.new(); add_child(product_settings)
    _build_ui();
    completion=CompletionDirectorV10.new(); add_child(completion); completion.setup(state,camera,hud_layer); completion.message.connect(func(msg): dialogue.show_line("SISTEMA",msg)) interiors.setup(player,builder); _load_world()
    perf.quality_changed.connect(_on_quality_changed)
    city_flow.on_mission_start(state.mission_index+1)
    mission_runtime.start(min(state.mission_index+1,10))
    experience.contract_completed.connect(func(title,reward): dialogue.show_line('CONTRATO','%s concluído: +%d créditos' % [title,reward]))
    experience.milestone.connect(func(text): dialogue.show_line('MARCO',text))
    if state.current_world=='Cidade Lua' and state.mission_index==0: cinematic.start(dialogue)
    if state.current_world=="Cidade Lua" and state.mission_index==0:
        intro.start(self,hud_layer)


func _open_settings():
    if is_instance_valid(settings_panel): settings_panel.queue_free(); settings_panel=null; return
    settings_panel=Panel.new(); settings_panel.position=Vector2(330,105); settings_panel.size=Vector2(620,500); hud_layer.add_child(settings_panel)
    var title=Label.new(); title.text='OPERAÇÃO LUA SOMBRIA • CONFIGURAÇÕES'; title.position=Vector2(24,20); title.add_theme_font_size_override('font_size',22); settings_panel.add_child(title)
    _settings_button('Bateria / desempenho: '+('ECONOMIA' if product_settings.battery_saver else 'NORMAL'),Vector2(24,75),func(): product_settings.toggle_battery_saver(); _refresh_settings())
    _settings_button('Vibração: '+('ON' if product_settings.vibration else 'OFF'),Vector2(24,140),func(): product_settings.toggle_vibration(); _refresh_settings())
    _settings_button('HUD: %.0f%%' % (product_settings.hud_scale*100.0),Vector2(24,205),func(): product_settings.set_hud_scale(product_settings.hud_scale+0.05); _refresh_settings())
    _settings_button('Sensibilidade: %.1fx' % product_settings.sensitivity,Vector2(24,270),func(): product_settings.set_sensitivity(product_settings.sensitivity+0.1 if product_settings.sensitivity<1.9 else 0.5); _refresh_settings())
    var info=Label.new(); info.text='Perfil A16 otimizado • 30 FPS alvo • modo offline • progresso salvo
Configurações ficam gravadas no dispositivo.'; info.position=Vector2(24,350); info.add_theme_font_size_override('font_size',16); settings_panel.add_child(info)
func _refresh_settings():
    if is_instance_valid(settings_panel):
        settings_panel.queue_free()
        settings_panel = null
    _open_settings()

func _settings_button(caption,pos,cb):
    var b=Button.new(); b.text=caption; b.position=pos; b.size=Vector2(360,50); b.pressed.connect(cb); settings_panel.add_child(b)

func _process(delta):
    state.day_time=fmod(state.day_time+delta*.03,24.0); firing_cooldown=max(0.0,firing_cooldown-delta); interaction_cooldown=max(0.0,interaction_cooldown-delta)
    scanner.recharge(delta); combat.tick(delta); cinematic.tick(delta,dialogue); completion.tick(delta,player) if completion else null; _update_environment(); _update_npcs(delta); builder.update_streaming(player,perf.quality); sectors.set_distance(device_profile.max_effect_distance); sectors.tick(player); traffic.tick(delta,player,device_profile.max_effect_distance); routines.tick(state.day_time,delta,player,device_profile.max_effect_distance); ai_director.tick(delta,player,enemies,state.current_world); police_ai.tick(delta,player,police_units); city_life.tick(delta,player,police_units); qa.sample(delta,get_tree().get_node_count()); experience.tick(delta,player,enemies); _update_ui()
    if Input.is_action_just_pressed('interact'): _interact()
    if Input.is_action_just_pressed('action'): _fire()
    if Input.is_action_just_pressed('reload'): _reload_weapon()
    if Input.is_action_just_pressed('swap_weapon'): _swap_weapon()
    if Input.is_action_just_pressed('aim'): animation_controller.aim(true)
    if Input.is_action_just_released('aim'): animation_controller.aim(false)
    if Input.is_action_just_pressed('map'): _cycle_world()
    if Input.is_action_just_pressed('vehicle'): _toggle_vehicle()
    if Input.is_action_just_pressed('inventory'): _use_medkit()
    if Input.is_action_just_pressed('scan') and interaction_cooldown<=0: _scan()
    if Input.is_action_just_pressed('drone') and interaction_cooldown<=0: _toggle_drone()
    if Input.is_action_just_pressed('photo_mode') and completion: completion.photo.toggle(); dialogue.show_line('SISTEMA','Photo Mode: '+('ATIVO' if completion.photo.active else 'DESATIVADO'))

func _physics_process(delta):
    if not player or (vehicle and vehicle.occupied): return
    var v:=Input.get_vector('move_left','move_right','move_forward','move_back'); var dir:=Vector3(v.x,0,v.y)
    if touch_stick.length()>.12: dir=Vector3(touch_stick.x,0,touch_stick.y)
    sprinting=Input.is_action_pressed('run'); current_speed=7.5 if sprinting else 5.0
    if dir.length()>.05:
        dir=dir.normalized(); player.velocity.x=dir.x*current_speed; player.velocity.z=dir.z*current_speed; player.look_at(player.global_position+Vector3(dir.x,0,dir.z),Vector3.UP)
    else:
        player.velocity.x=move_toward(player.velocity.x,0,22*delta); player.velocity.z=move_toward(player.velocity.z,0,22*delta)
    player.velocity.y=-3; player.move_and_slide(); animation_controller.set_movement(Vector2(player.velocity.x,player.velocity.z).length(), false); player.global_position.x=clamp(player.global_position.x,-112.,112.); player.global_position.z=clamp(player.global_position.z,-112.,112.); _camera_follow(delta)

func _load_world():
    builder.build(state.current_world,state.mission_index); traffic.clear_vehicles(); _clear_actors(); _spawn_actors(); _spawn_vehicle(); _spawn_city_tech(); _spawn_city_traffic()
    if state.current_world=="Cidade Lua":
        city_lua=CidadeLua2074.new(); city_lua.name="CidadeLua2074"; builder.add_child(city_lua); city_lua.build(builder,builder)

func _clear_actors():
    for n in enemies+npcs:
        if is_instance_valid(n):
            routines.unregister(n)
            n.queue_free()
    enemies.clear(); npcs.clear(); police_units.clear()
    if is_instance_valid(vehicle): vehicle.queue_free(); vehicle=null

func _spawn_actors():
    var rng:=RandomNumberGenerator.new(); rng.seed=4040+state.mission_index*31
    var civil_count=12 if state.current_world in ['Cidade Lua','Cidade Nova','Porto Velho'] else 7
    var hostile_count=4 if state.mission_index<70 else 6
    civil_count=min(civil_count,device_profile.max_active_civilians)
    hostile_count=min(hostile_count,device_profile.max_active_hostiles)
    for i in range(civil_count):
        var home=Vector3(rng.randf_range(-75,75),1,rng.randf_range(-75,75))
        var work=Vector3(rng.randf_range(-75,75),1,rng.randf_range(-75,75))
        var shop=Vector3(rng.randf_range(-75,75),1,rng.randf_range(-75,75))
        _spawn_npc(home,false)
        if npcs.size()>0:
            routines.register(npcs.back(),home,work,shop)
    for i in range(hostile_count):
        _spawn_npc(Vector3(rng.randf_range(-70,70),1,rng.randf_range(-70,70)),true)
    for e in enemies:
        var ai=EnemyCombatAI2074.new(); ai.name='CombatAI2074'; e.add_child(ai); ai.setup(e,player,enemies); ai.request_reinforcements.connect(func(_enemy): dialogue.show_line('IA TÁTICA','Reforços solicitados.'))
    if state.current_world=='Cidade Lua':
        for i in range(min(3,device_profile.max_active_civilians)):
            _spawn_police(Vector3(-50+i*45,1,-55))

func _spawn_police(pos:Vector3):
    var n=CharacterBody3D.new(); n.name='Policial_2074'; n.set_meta('state','patrol'); var mesh=MeshInstance3D.new(); var cap=CapsuleMesh.new(); cap.height=1.8; cap.radius=.34; cap.material=_material(Color(.06,.10,.18)); mesh.mesh=cap; mesh.position.y=.9; n.add_child(mesh); var cs=CollisionShape3D.new(); var shape=CapsuleShape3D.new(); shape.height=1.8; shape.radius=.34; cs.shape=shape; cs.position.y=.9; n.add_child(cs); n.position=pos; builder.add_child(n); police_units.append(n)

func _spawn_npc(pos:Vector3,hostile:bool):
    var n=CharacterBody3D.new(); n.name='Hostil_2074' if hostile else 'Civil_2074'; var mesh=MeshInstance3D.new(); var cap=CapsuleMesh.new(); cap.height=1.7; cap.radius=.32; cap.material=_material(Color(.65,.06,.05) if hostile else Color(.08,.30,.55)); mesh.mesh=cap; mesh.position.y=.9; n.add_child(mesh)
    var cs=CollisionShape3D.new(); var shape=CapsuleShape3D.new(); shape.height=1.7; shape.radius=.32; cs.shape=shape; cs.position.y=.9; n.add_child(cs); n.position=pos; builder.add_child(n); npcs.append(n); if hostile: enemies.append(n)

func _build_player():
    player=CharacterBody3D.new(); player.name='YABA'
    var model_path='res://assets/models/YABA_2074_exosuit.glb'; var model=load(model_path).instantiate() if ResourceLoader.exists(model_path) else null
    if model: player.add_child(model)
    else:
        var mesh=MeshInstance3D.new(); var cap=CapsuleMesh.new(); cap.height=1.8; cap.radius=.38; cap.material=_material(Color(.04,.05,.06)); mesh.mesh=cap; mesh.position.y=1; player.add_child(mesh)
    var cs=CollisionShape3D.new(); var shape=CapsuleShape3D.new(); shape.height=1.8; shape.radius=.38; cs.shape=shape; cs.position.y=1; player.add_child(cs); player.position=Vector3(0,1,25); add_child(player)
    animation_controller=YABAAnimationController2074.new(); player.add_child(animation_controller); animation_controller.setup(player)
    if ResourceLoader.exists('res://assets/models/weapon_2074_pulse_carbine.glb'):
        var weapon=load('res://assets/models/weapon_2074_pulse_carbine.glb').instantiate(); weapon.position=Vector3(.45,1.05,-.45); weapon.rotation_degrees=Vector3(0,90,0); player.add_child(weapon)

func _build_camera():
    pivot=Node3D.new(); pivot.position=Vector3(0,1.25,0); player.add_child(pivot); camera=Camera3D.new(); camera.position=Vector3(0,4.8,7.8); camera.rotation_degrees=Vector3(-17,180,0); camera.current=true; pivot.add_child(camera)
func _camera_follow(delta): pivot.rotation.y=lerp_angle(pivot.rotation.y,player.rotation.y,delta*5)

func _open_value_graph():
    if value_graph and is_instance_valid(value_graph):
        value_graph.queue_free(); value_graph=null; return
    var panel=Panel.new(); panel.name='ValueGraphPanel'; panel.position=Vector2(230,95); panel.size=Vector2(820,400); hud_layer.add_child(panel)
    value_graph=ValorGraph2074.new(); panel.add_child(value_graph); value_graph.position=Vector2(20,20); value_graph.size=Vector2(780,360); value_graph.setup(state)
    var close=Button.new(); close.text='FECHAR'; close.position=Vector2(690,5); close.size=Vector2(105,42); close.pressed.connect(func(): panel.queue_free(); value_graph=null); panel.add_child(close)

func _build_ui():
    var layer=CanvasLayer.new(); layer.name='HUD'; add_child(layer); hud_layer=layer
    var panel=ColorRect.new(); panel.color=Color(.008,.02,.045,.9); panel.position=Vector2(16,16); panel.size=Vector2(560,158); layer.add_child(panel)
    ui_info=Label.new(); ui_info.position=Vector2(14,10); ui_info.add_theme_font_size_override('font_size',17); panel.add_child(ui_info)
    objective_label=Label.new(); objective_label.position=Vector2(18,180); objective_label.size=Vector2(760,80); objective_label.add_theme_font_size_override('font_size',17); layer.add_child(objective_label)
    status_label=Label.new(); status_label.position=Vector2(18,250); status_label.size=Vector2(760,60); status_label.add_theme_font_size_override('font_size',15); layer.add_child(status_label)
    _button(layer,'AÇÃO',Vector2(1090,560),'action'); _button(layer,'INTERAGIR',Vector2(920,560),'interact'); _button(layer,'MAPA',Vector2(920,625),'map'); _button(layer,'VEÍCULO',Vector2(1090,625),'vehicle'); _button(layer,'KIT',Vector2(760,625),'inventory'); _button(layer,'SCAN',Vector2(600,625),'scan'); _button(layer,'DRONE',Vector2(600,560),'drone'); _button(layer,'CONFIG',Vector2(1080,18),'settings'); _button(layer,'VALOR',Vector2(930,18),'value_graph')
    var hint=Label.new(); hint.text='PC: WASD / Espaço / E / M / F=Scanner / G=Drone • Android: botões na tela'; hint.position=Vector2(18,680); hint.add_theme_font_size_override('font_size',13); layer.add_child(hint); _build_virtual_stick(layer)

func _button(layer,caption,pos,action_name):
    var b=Button.new(); b.text=caption; b.position=pos; b.size=Vector2(135,52); b.add_theme_font_size_override('font_size',15); if action_name=='value_graph': b.pressed.connect(_open_value_graph); else: b.pressed.connect(func(): Input.action_press(action_name); await get_tree().process_frame; Input.action_release(action_name)); layer.add_child(b)
func _build_virtual_stick(layer):
    var b=Button.new(); b.name='VirtualStick'; b.text='MOVE'; b.position=Vector2(40,545); b.size=Vector2(180,110); b.modulate=Color(1,1,1,.72); b.gui_input.connect(_stick_input); layer.add_child(b)
func _stick_input(event):
    if event is InputEventScreenTouch:
        if event.pressed: touch_stick_center=event.position
        else: touch_stick=Vector2.ZERO
    elif event is InputEventScreenDrag: touch_stick=((event.position-touch_stick_center)/70.).limit_length(1.)

func _update_npcs(delta):
    var active_dist=perf.actor_distance()
    for n in enemies:
        if not is_instance_valid(n): continue
        var dist=n.global_position.distance_to(player.global_position)
        var ai=n.get_node_or_null('CombatAI2074')
        if ai and dist<active_dist:
            ai.tick(delta)
        elif dist<active_dist:
            var dir=(player.global_position-n.global_position).normalized(); n.velocity=dir*1.8; n.move_and_slide()
        else: n.velocity=Vector3.ZERO
        if dist<2: state.hp=max(0.,state.hp-delta*7.)
    for i in range(npcs.size()):
        var n=npcs[i]
        if is_instance_valid(n) and n not in enemies and i%3==0 and fmod(Time.get_ticks_msec()/1000.,6.0)<delta: n.position.x=clamp(n.position.x+sin(Time.get_ticks_msec()/700.0+i)*2.,-105.,105.)

func _fire():
    animation_controller.fire()
    var before=state.weapon_ammo
    state.weapon_ammo=combat.fire(player,enemies,state.weapon_ammo)
    if state.weapon_ammo != before: state.save_game()

func _reload_weapon():
    animation_controller.reload()
    state.weapon_ammo=30
    dialogue.show_line('YABA','Recarga concluída.')
    state.save_game()

func _swap_weapon():
    animation_controller.swap_weapon()
    dialogue.show_line('YABA','Arma alternada.')

func _interact():
    if interaction_cooldown>0:return
    interaction_cooldown=.6
    var near_access=_nearest_access_point()
    if near_access:
        var req=int(near_access.get_meta("access_level",0))
        var label=str(near_access.get_meta("label","Acesso"))
        if not access_cards.unlock(req,state):
            dialogue.show_line("Sistema 2074","Acesso negado — cartão nível %d necessário" % req)
            return
        if label=="Loja":
            services.use("shop")
        elif label=="Garagem":
            services.use("garage")
        elif label=="Hospital":
            services.use("hospital")
        elif label=="Metrô":
            services.use("metro")
        elif label=="Delegacia":
            services.use("police")
            if access_cards.grant_card(max(2,access_cards.level),state): dialogue.show_line("Polícia","Credencial policial registrada.")
        else:
            dialogue.show_line("Sistema 2074","Acesso autorizado — "+access_cards.card_name())
        return
    var d=player.global_position.distance_to(builder.mission_marker.global_position) if is_instance_valid(builder.mission_marker) else 999
    if interior:
        _leave_interior(); return
    if d<4.5:
        var done=missions.advance()
        var story_done=mission_runtime.advance()
        if done or story_done: _complete_mission()
        else: state.mission_objective=missions.objective_index; state.save_game()
    else:
        var near_door=_nearest_interior_door()
        if near_door:
            _enter_interior(near_door)
        else:
            dialogue.show_line('YABA','Interface 2074: nenhum ponto interativo prioritário nesta área.')

func _nearest_access_point():
    var best=null; var best_d=4.0
    for n in get_tree().get_nodes_in_group("access_point"):
        if is_instance_valid(n):
            var d=player.global_position.distance_to(n.global_position)
            if d<best_d: best=n; best_d=d
    return best

func _complete_mission():
    city_flow.on_objective_complete(state.mission_index+1)
    state.mission_index=min(MISSION_COUNT,state.mission_index+1); state.mission_objective=0; state.credits+=150; state.reputation+=2; state.hp=min(100.,state.hp+10.)
    if state.mission_index>=73 and state.current_world=='Complexo Lua': state.current_world='Centro Espacial'
    elif state.mission_index>=79 and state.current_world=='Centro Espacial': state.current_world='Lua'
    elif state.mission_index>=84 and state.current_world=='Lua': state.current_world='Marte'
    state.discovered[state.current_world]=true; missions.start(state.mission_index+1); experience.register_mission(); state.save_game(); _load_world(); dialogue.show_line('YABA','Missão concluída. Próximo setor desbloqueado.')

func _cycle_world():
    var idx=REGIONS.find(state.current_world); idx=(idx+1)%REGIONS.size(); state.current_world=REGIONS[idx]; state.discovered[state.current_world]=true; state.save_game(); _load_world()

func _spawn_vehicle():
    vehicle=VehicleController.new(); vehicle.name='Vehicle_2074_'+state.vehicle_type; vehicle.vehicle_kind=state.vehicle_type; vehicle.max_speed=18.0 if state.vehicle_type=='car' else 22.0; var model_file='vehicle_car_2074.glb'
    if state.vehicle_type=='motorcycle': model_file='vehicle_motorcycle_2074.glb'
    elif state.vehicle_type=='boat': model_file='vehicle_boat_2074.glb'
    elif state.vehicle_type=='rover': model_file='rover_planetary_2074.glb'
    elif state.vehicle_type=='shuttle': model_file='ship_shuttle_2074.glb'
    if ResourceLoader.exists('res://assets/models/'+model_file): vehicle.add_child(load('res://assets/models/'+model_file).instantiate())
    var cs=CollisionShape3D.new(); var sh=BoxShape3D.new(); sh.size=Vector3(2.4,1.2,4.0); cs.shape=sh; cs.position.y=.7; vehicle.add_child(cs); vehicle.position=player.position+Vector3(4,0,3); add_child(vehicle)

func _toggle_vehicle():
    if not is_instance_valid(vehicle):return
    if not vehicle.occupied:
        if player.global_position.distance_to(vehicle.global_position)<5: vehicle.occupied=true; player.visible=false; vehicle.position.y=.4; experience.register_vehicle()
    else:
        vehicle.occupied=false; player.visible=true; player.global_position=vehicle.global_position+Vector3(2,0,0)

func _spawn_city_traffic():
    if state.current_world != 'Cidade Lua': return
    for i in range(6):
        traffic.spawn_model_vehicle(i, 5.5 + float(i%3))

func _spawn_city_tech():
    if ResourceLoader.exists('res://assets/models/drone_scout_2074.glb'):
        drone_model=load('res://assets/models/drone_scout_2074.glb').instantiate(); drone_model.visible=false; drone.add_child(drone_model)
    if state.current_world in ['Cidade Lua','Cidade Nova','Centro Espacial','Lua','Marte']:
        for i in range(4):
            if ResourceLoader.exists('res://assets/models/hologram_beacon_2074.glb'):
                var h=load('res://assets/models/hologram_beacon_2074.glb').instantiate(); h.position=Vector3(-65+i*43,.1,-35); builder.add_child(h)

func _scan():
    interaction_cooldown=.5; scanner_text=scanner.scan(player,npcs); experience.register_scan(); dialogue.show_line('SCANNER',scanner_text)
func _toggle_drone():
    interaction_cooldown=.5
    if not drone.deployed and state.drone_charges>0:
        state.drone_charges-=1
        experience.register_vehicle()
        drone.deploy(player.global_position)
        if drone_model:
            drone_model.visible=true
        dialogue.show_line('DRONE','Unidade Scout 2074 implantada. Transmissão ativa.')
    else:
        drone.recall()
        if drone_model:
            drone_model.visible=false
        dialogue.show_line('DRONE','Unidade recolhida.')
    state.save_game()
func _nearest_interior_door():
    var best=null; var best_d=5.0
    for n in builder.get_tree().get_nodes_in_group('interior_door'):
        if is_instance_valid(n):
            var d=player.global_position.distance_to(n.global_position)
            if d<best_d: best=n; best_d=d
    return best

func _enter_interior(door):
    interior=true; interior_anchor=player.global_position
    var iname=str(door.get_meta('interior_name','Apartamento'))
    var paths={'Apartamento':'res://assets/models/cidade_lua/apartment_interior_2074.glb','Delegacia':'res://assets/models/cidade_lua/police_interior_2074.glb','Hospital':'res://assets/models/cidade_lua/hospital_interior_2074.glb','Garagem':'res://assets/models/cidade_lua/garage_interior_2074.glb','Metrô':'res://assets/models/cidade_lua/metro_interior_2074.glb'}
    if ResourceLoader.exists(paths.get(iname,'')):
        active_interior_model=load(paths[iname]).instantiate(); active_interior_model.position=Vector3(0,0,0); builder.add_child(active_interior_model)
    player.global_position=door.get_meta('interior_position',door.global_position+Vector3(0,0,-5)); dialogue.show_line('YABA','Interior '+iname+' conectado. Sistema predial 2074 ativo.')

func _leave_interior():
    interior=false
    if is_instance_valid(active_interior_model): active_interior_model.queue_free(); active_interior_model=null
    player.global_position=interior_anchor; dialogue.show_line('YABA','Retornando ao exterior.')

func _use_medkit():
    if int(state.inventory.get('kit_medico',0))<=0 or state.hp>=100:return
    state.inventory['kit_medico']=int(state.inventory.get('kit_medico',0))-1; state.hp=min(100.,state.hp+35.); state.reputation+=1; state.save_game()

func _update_environment():
    var env_node=builder.get_node_or_null('Environment'); if not env_node:return
    var env:Environment=env_node.environment; var night=state.day_time<6 or state.day_time>19; env.ambient_light_energy=.25 if night else .82
    env.fog_enabled=state.weather in ['storm','dust','fog']; env.fog_density=.012 if state.weather=='storm' else .006
func _on_quality_changed(q):
    var sun=builder.get_node_or_null('DirectionalLight3D'); if sun: sun.directional_shadow_max_distance=perf.shadow_distance()
func _update_ui():
    if not ui_info:return
    var idx=min(state.mission_index,MISSION_COUNT-1); var title='Exploração livre' if state.mission_index>=MISSION_COUNT else MISSIONS[idx]
    ui_info.text='YABA • %s • 2074\nMissão %d/100 • %s\nHP %.0f • Munição %d • Créditos %d\nCartão %d • Scanner %.0f%% • Drone %d • Qualidade %d' % [state.current_world,state.mission_index+1,title,state.hp,state.weapon_ammo,state.credits,int(state.inventory.get("access_card_level",0)),scanner.energy,state.drone_charges,perf.quality]
    objective_label.text='OBJETIVO: %s\nLocal: %s' % [mission_runtime.objective_text() if state.mission_index<10 else missions.objective(),state.current_world]
    status_label.text='Clima: %s • Hora: %02d:%02d • Veículo: %s • Reputação: %d\n%s\n%s' % [state.weather,int(state.day_time),int(fmod(state.day_time*60,60)),state.vehicle_type,state.reputation,scanner_text,experience.summary()]
func _material(c:Color)->StandardMaterial3D:
    var m=StandardMaterial3D.new(); m.albedo_color=c; m.roughness=.88; return m

func _input(event):
    if event.is_action_pressed('settings'): _open_settings()
