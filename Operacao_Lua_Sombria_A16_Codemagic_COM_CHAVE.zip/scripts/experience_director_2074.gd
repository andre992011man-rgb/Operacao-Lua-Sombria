class_name ExperienceDirector2074
extends Node

## Camada de retenção/polimento: contratos rotativos, streak e métricas de sessão.
## Não depende de rede e funciona offline no Android.
var state: GameState
var session_seconds := 0.0
var session_distance := 0.0
var session_kills := 0
var streak := 0
var streak_timer := 0.0
var contract_id := 0
var contract_title := "Contrato ativo"
var contract_target := 1
var contract_progress := 0
var contract_reward := 100
var contract_kind := "kills"
var last_position := Vector3.ZERO
var initialized := false

signal contract_completed(title: String, reward: int)
signal milestone(text: String)

func setup(game_state: GameState, player: Node3D) -> void:
    state = game_state
    last_position = player.global_position if player else Vector3.ZERO
    contract_id = int(state.inventory.get("contract_id", state.mission_index % 6))
    _roll_contract()
    initialized = true

func tick(delta: float, player: Node3D, enemies: Array) -> void:
    if not initialized or not player: return
    session_seconds += delta
    var moved := player.global_position.distance_to(last_position)
    if moved < 20.0:
        session_distance += moved
        if contract_kind == "distance":
            contract_progress = int(session_distance)
            _check_contract()
    last_position = player.global_position
    streak_timer = max(0.0, streak_timer - delta)
    if streak_timer <= 0.0 and streak > 0:
        streak = 0
    if session_seconds >= 60.0 and int(session_seconds - delta) < 60:
        milestone.emit("Sessão 1 minuto registrada")
    if int(session_distance) >= 1000 and int(session_distance - moved) < 1000:
        milestone.emit("Explorador: 1 km percorrido")
    _update_contract(enemies)

func register_kill() -> void:
    session_kills += 1
    streak += 1
    streak_timer = 8.0
    if contract_kind == "kills":
        contract_progress += 1
    if streak == 5 or streak == 10 or streak == 20:
        milestone.emit("STREAK x%d" % streak)
    _check_contract()

func register_scan() -> void:
    if contract_kind == "scans":
        contract_progress += 1
    _check_contract()

func register_vehicle() -> void:
    if contract_kind == "vehicles":
        contract_progress += 1
    _check_contract()

func register_mission() -> void:
    if not state: return
    state.reputation += 1 + min(streak / 5, 3)
    state.inventory["missions_mastered"] = int(state.inventory.get("missions_mastered", 0)) + 1
    if contract_kind == "missions":
        contract_progress += 1
        if contract_progress >= contract_target:
            _check_contract()
            return
    _roll_contract()

func summary() -> String:
    return "Sessão %02d:%02d • %d eliminações • %.0f m • Contrato %d/%d" % [int(session_seconds)/60, int(session_seconds)%60, session_kills, session_distance, contract_progress, contract_target]

func _update_contract(enemies: Array) -> void:
    if enemies.size() > 0 and contract_id % 3 == 0:
        # Contratos de combate progridem por eliminações registradas externamente.
        pass

func _roll_contract() -> void:
    if not state: return
    contract_id = (state.mission_index + int(state.inventory.get("contract_roll", 0))) % 6
    state.inventory["contract_roll"] = int(state.inventory.get("contract_roll", 0)) + 1
    contract_progress = 0
    match contract_id:
        0:
            contract_title = "Resposta rápida"; contract_target = 5; contract_reward = 260; contract_kind = "kills"
        1:
            contract_title = "Patrulha urbana"; contract_target = 450; contract_reward = 220; contract_kind = "distance"
        2:
            contract_title = "Caça aos sinais"; contract_target = 2; contract_reward = 200; contract_kind = "scans"
        3:
            contract_title = "Operação limpa"; contract_target = 1; contract_reward = 300; contract_kind = "missions"
        4:
            contract_title = "Mobilidade tática"; contract_target = 2; contract_reward = 280; contract_kind = "vehicles"
        _:
            contract_title = "Reconhecimento"; contract_target = 600; contract_reward = 240; contract_kind = "distance"
    state.inventory["contract_id"] = contract_id
    state.inventory["contract_title"] = contract_title
    state.inventory["contract_target"] = contract_target
    state.inventory["contract_progress"] = 0
    state.inventory["contract_reward"] = contract_reward

func _check_contract() -> void:
    if not state or contract_progress < contract_target: return
    state.credits += contract_reward
    state.reputation += 3
    state.side_missions_completed += 1
    contract_completed.emit(contract_title, contract_reward)
    _roll_contract()
    state.save_game()
