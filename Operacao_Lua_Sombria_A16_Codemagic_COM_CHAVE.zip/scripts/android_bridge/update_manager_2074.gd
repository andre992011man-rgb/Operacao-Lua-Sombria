class_name UpdateManager2074
extends Node

signal update_available(version:String, url:String)
signal update_progress(done:int, total:int)
signal update_finished(ok:bool, message:String)

const MANIFEST_PATH := "res://data/android/update_manifest.json"
var manifest:Dictionary = {}
var http:HTTPRequest

func _ready() -> void:
    _load_manifest()
    http=HTTPRequest.new(); add_child(http)
    http.request_completed.connect(_on_request_completed)

func _load_manifest() -> void:
    if not FileAccess.file_exists(MANIFEST_PATH): return
    var f:=FileAccess.open(MANIFEST_PATH,FileAccess.READ)
    if f:
        var d=JSON.parse_string(f.get_as_text())
        if typeof(d)==TYPE_DICTIONARY: manifest=d
        f.close()

func get_current_version() -> String:
    return str(manifest.get("version","0.6.2074"))

func get_download_url() -> String:
    return str(manifest.get("apk_url",""))

func check_manifest(url:String) -> void:
    if url.is_empty():
        update_finished.emit(false,"URL de atualização não configurada")
        return
    var err:=http.request(url)
    if err != OK: update_finished.emit(false,"Falha ao iniciar verificação")

func _on_request_completed(result:int, code:int, headers:PackedStringArray, body:PackedByteArray) -> void:
    if result != HTTPRequest.RESULT_SUCCESS or code < 200 or code >= 300:
        update_finished.emit(false,"Servidor indisponível")
        return
    var d=JSON.parse_string(body.get_string_from_utf8())
    if typeof(d)!=TYPE_DICTIONARY:
        update_finished.emit(false,"Manifesto inválido")
        return
    var remote=str(d.get("version",get_current_version()))
    if remote != get_current_version(): update_available.emit(remote,str(d.get("apk_url","")))
    else: update_finished.emit(true,"Jogo já está atualizado")
