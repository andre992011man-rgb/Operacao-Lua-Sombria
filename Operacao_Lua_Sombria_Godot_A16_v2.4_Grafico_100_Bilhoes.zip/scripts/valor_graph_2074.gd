class_name ValorGraph2074
extends Control
## Gráfico visual de evolução econômica da operação. É uma métrica fictícia interna do jogo.
var state: Node
var history: Array[float] = []
var target := 100_000_000_000.0
var timer := 0.0

func setup(game_state: Node) -> void:
    state = game_state
    custom_minimum_size = Vector2(760, 360)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    _load_history()
    queue_redraw()

func _process(delta: float) -> void:
    timer += delta
    if timer >= 12.0:
        timer = 0.0
        _record()
        queue_redraw()

func _record() -> void:
    if not state: return
    var credits := float(state.credits)
    var reputation := float(state.reputation)
    var missions := float(state.mission_index)
    # Índice interno, deliberadamente separado de valuation real.
    var value := clamp(1_000_000_000.0 + credits * 2_000_000.0 + reputation * 35_000_000.0 + missions * 250_000_000.0, 0.0, target)
    history.append(value)
    if history.size() > 12: history.pop_front()
    state.inventory["value_graph_history"] = history
    state.save_game()

func _load_history() -> void:
    if state:
        var raw = state.inventory.get("value_graph_history", [])
        history.clear()
        for x in raw:
            history.append(float(x))
    if history.is_empty():
        history.append(1_000_000_000.0)

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, size), Color(0.025,0.04,0.075,0.98), true)
    draw_rect(Rect2(Vector2(18,18), Vector2(size.x-36,size.y-36)), Color(0.04,0.06,0.11,1.0), true)
    var font := ThemeDB.fallback_font
    draw_string(font, Vector2(34,48), "ÍNDICE DE VALOR DA OPERAÇÃO", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(0.88,0.94,1.0))
    draw_string(font, Vector2(34,76), "Meta visual interna: R$ 100 bilhões", HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(0.55,0.75,0.9))
    var chart := Rect2(46,98,size.x-92,size.y-142)
    for i in range(1,5):
        var y := chart.position.y + chart.size.y * float(i)/4.0
        draw_line(Vector2(chart.position.x,y), Vector2(chart.end.x,y), Color(0.18,0.24,0.34,1), 1.0)
    if history.size() < 2: return
    var points := PackedVector2Array()
    for i in range(history.size()):
        var x := chart.position.x + chart.size.x * float(i)/float(max(1,history.size()-1))
        var ratio := clamp(history[i]/target,0.0,1.0)
        var y := chart.end.y - chart.size.y * ratio
        points.append(Vector2(x,y))
    for i in range(points.size()-1):
        draw_line(points[i],points[i+1],Color(0.25,0.85,1.0,1),4.0,true)
    for p in points:
        draw_circle(p,6.0,Color(0.9,0.98,1.0,1))
    var current := history.back()
    draw_string(font, Vector2(chart.position.x,chart.end.y+30), "R$ %.1f bi" % (current/1_000_000_000.0), HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(0.85,0.95,1.0))
    draw_string(font, Vector2(chart.end.x-190,chart.end.y+30), "100 bi = meta", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(0.55,0.75,0.9))
