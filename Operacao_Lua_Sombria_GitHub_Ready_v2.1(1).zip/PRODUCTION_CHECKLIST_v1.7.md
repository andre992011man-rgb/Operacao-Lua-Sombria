# Operação Lua Sombria — Produção v1.7

- [x] Own Android v2 plugin source
- [x] Offline AAR debug/release generated
- [x] EditorExportPlugin points to AAR
- [x] ARM64 Android export configuration retained
- [x] APK/AAB Gradle export configuration retained
- [x] Offline toolchain verifier
- [x] zipalign -> apksigner release script
- [x] Own-key-only signing policy
- [x] Third-party license policy
- [ ] Run real Godot export
- [ ] Run real Gradle/AAPT2 build
- [ ] zipalign output
- [ ] sign with a release keystore owned by the project owner
- [ ] apksigner verify
- [ ] install/test on Galaxy A16

The last items require a real Android build toolchain. The project does not claim those steps were executed here.
