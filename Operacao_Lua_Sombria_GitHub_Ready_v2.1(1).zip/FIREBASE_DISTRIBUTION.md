# Etapa 4 — Firebase App Distribution

O projeto pode distribuir o APK produzido pelo CI para testadores confiáveis.

Variáveis protegidas do CI:
- `FIREBASE_APP_ID`: identificador do app Android no Firebase.
- `FIREBASE_TESTER_GROUPS`: grupo(s) de testadores, separados por vírgula.
- Autenticação do Firebase CLI deve ser configurada como segredo do serviço de CI.

Comando preparado:
`tools/ci/firebase_distribute.sh`

O Firebase App Distribution é um serviço oficial do Firebase para distribuir builds Android a testadores. O App Distribution é listado como produto sem custo financeiro no plano Spark; outros recursos, como determinados testes do Test Lab, possuem quotas/condições próprias.
