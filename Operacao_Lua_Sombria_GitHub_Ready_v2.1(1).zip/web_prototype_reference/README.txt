OPERAÇÃO LUA SOMBRIA — YABA
PROTÓTIPO JOGÁVEL OFFLINE / ANDROID

COMO JOGAR NO ANDROID:
1. Extraia este ZIP.
2. Abra index.html no Chrome.
3. Para instalar como aplicativo: menu do Chrome > Adicionar à tela inicial/Instalar app.
4. O jogo funciona offline depois do primeiro carregamento.

CONTROLES:
- Celular: joystick esquerdo, CORRER, AÇÃO, ENTRAR.
- PC: WASD, Shift, Espaço, E, M.

RECURSOS:
- YABA como protagonista.
- 100 missões cadastradas.
- Mapa terrestre e mundos espaciais.
- Viagem entre regiões.
- Combate básico.
- NPCs/inimigos simplificados.
- Veículos representados no protótipo.
- Salvamento local.
- PWA/offline.

IMPORTANTE:
Este é um protótipo jogável em HTML5, não um APK 3D comercial completo. O APK enviado anteriormente contém apenas um launcher pequeno e não possui uma engine/jogo 3D para receber todas as funcionalidades. Para um APK nativo completo é necessário um projeto de engine Android e um ambiente de build Android.
