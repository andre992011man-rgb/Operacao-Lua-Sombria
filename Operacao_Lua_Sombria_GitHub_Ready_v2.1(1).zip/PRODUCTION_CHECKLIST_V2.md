# Operação Lua Sombria — Produção Android V2

## Pipeline
1. QA estrutural: `python3 tests/test_project.py`.
2. Baixar Godot 4.7.2 e export templates por endpoint oficial.
3. Preparar Android SDK 35 / Build Tools 35.0.0.
4. Smoke export: APK debug para validação rápida.
5. Release export: APK + AAB.
6. Verificar que todos os artefatos existem e não estão vazios.
7. Gerar SHA256SUMS.txt.
8. No Codemagic, usar Quick Launch no APK para teste no navegador/emulador.
9. Para distribuição, assinar o release com keystore protegida no CI.
10. Depois do teste, distribuir pelo Firebase App Distribution ou Play Console.

## Critério de “pronto”
Só marcar como pronto quando um serviço de CI retornar com sucesso e os artefatos APK/AAB estiverem disponíveis. A QA estática local, sozinha, não comprova uma compilação Android real.
