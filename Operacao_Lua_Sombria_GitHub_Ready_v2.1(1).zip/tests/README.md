# Testadores automatizados — Lua Sombria 2074

O projeto agora inclui uma camada de QA automatizado:

1. `test_project.py` — valida estrutura, JSON, 100 missões, mundos, modelos e referências `res://`.
2. `smoke_test.gd` — valida recursos críticos quando o Godot CLI estiver instalado.
3. `qa_telemetry.gd` — coleta amostras de frame e avisa sobre excesso de nodes/frames lentos durante a execução.

Os testes automatizados não substituem testes em um Galaxy A16 físico. FPS, aquecimento, bateria, touch e drivers precisam ser medidos no aparelho.
