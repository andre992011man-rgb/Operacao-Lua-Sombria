extends SceneTree

func _init():
    var required := [
        "res://scenes/Main.tscn",
        "res://scripts/main.gd",
        "res://data/missions_100_detailed.json",
        "res://data/worlds_2074.json",
        "res://assets/models/YABA_2074_exosuit.glb"
    ]
    var failed := false
    for path in required:
        if not ResourceLoader.exists(path):
            push_error("SMOKE FAIL: " + path)
            failed = true
        else:
            print("SMOKE PASS: " + path)
    var missions = FileAccess.open("res://data/missions_100_detailed.json", FileAccess.READ)
    if missions:
        var parsed = JSON.parse_string(missions.get_as_text())
        var list = parsed.get("missions", []) if typeof(parsed) == TYPE_DICTIONARY else parsed
        if typeof(list) != TYPE_ARRAY or list.size() != 100:
            push_error("SMOKE FAIL: esperado 100 missoes")
            failed = true
        else:
            print("SMOKE PASS: 100 missoes")
    quit(1 if failed else 0)
