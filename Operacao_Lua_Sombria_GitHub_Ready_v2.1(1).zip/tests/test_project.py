#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors = []
checks = []

def ok(name, cond, detail=''):
    checks.append((name, cond, detail))
    if not cond:
        errors.append(f'{name}: {detail}')

ok('project.godot existe', (ROOT/'project.godot').exists())
ok('Main.tscn existe', (ROOT/'scenes/Main.tscn').exists())
for p in ['scripts/main.gd','scripts/game_state.gd','scripts/mission_manager.gd','scripts/device_profile.gd','scripts/traffic_system.gd','scripts/npc_routine_system.gd','scripts/ai_director.gd','scripts/shop_system.gd','scripts/upgrade_system.gd','scripts/sector_streaming_2074.gd','scripts/qa_telemetry.gd']:
    ok(f'script {p}', (ROOT/p).exists())

for data_file in ['data/missions_100_detailed.json','data/worlds_2074.json','data/game_2074.json','data/vertical_slice.json']:
    path=ROOT/data_file
    try:
        data=json.loads(path.read_text(encoding='utf-8'))
        ok(f'JSON valido {data_file}', True)
    except Exception as e:
        ok(f'JSON valido {data_file}', False, str(e))

m=ROOT/'data/missions_100_detailed.json'
if m.exists():
    data=json.loads(m.read_text(encoding='utf-8'))
    missions=data.get('missions', []) if isinstance(data, dict) else data
    ok('100 missoes', len(missions)==100, f'quantidade={len(missions)}')

worlds=ROOT/'data/worlds_2074.json'
if worlds.exists():
    d=json.loads(worlds.read_text(encoding='utf-8'))
    ok('mundos 2074', len(d)>=20, f'quantidade={len(d)}')

models=list((ROOT/'assets/models').glob('*.glb'))
ok('modelos GLB', len(models)>=20, f'quantidade={len(models)}')

# Confere paths res:// usados no GDScript.
refs=set()
for gd in (ROOT/'scripts').glob('*.gd'):
    text=gd.read_text(encoding='utf-8', errors='ignore')
    refs.update(re.findall(r"res://[^'\"\s)]+", text))
for ref in sorted(refs):
    if ref.endswith('/'):
        continue
    ok(f'recurso {ref}', (ROOT/ref[6:]).exists(), 'arquivo ausente')

# Detecta class_name duplicado.
classes={}
for gd in (ROOT/'scripts').glob('*.gd'):
    text=gd.read_text(encoding='utf-8', errors='ignore')
    for cls in re.findall(r'^class_name\s+(\w+)', text, re.M):
        classes.setdefault(cls,[]).append(str(gd.relative_to(ROOT)))
for cls, files in classes.items():
    ok(f'class_name unico {cls}', len(files)==1, ', '.join(files))

print(f'QA estatica: {len(checks)} verificacoes; {len(errors)} falhas')
for name, cond, detail in checks:
    print(('PASS' if cond else 'FAIL'), '-', name, (f'[{detail}]' if detail and not cond else ''))
if errors:
    sys.exit(1)
