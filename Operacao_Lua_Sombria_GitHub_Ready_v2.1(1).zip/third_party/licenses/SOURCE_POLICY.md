# Operação Lua Sombria — Política de fontes e licenças

Este projeto só incorpora conteúdo externo quando a licença/origem permite explicitamente o uso pretendido.

Preferências:
1. Código e ferramentas oficiais (Godot, Android SDK/Build Tools, Gradle).
2. Domínio público/CC0.
3. Licenças permissivas (MIT, BSD, Apache-2.0) quando compatíveis.
4. CC-BY/CC-BY-SA somente quando a atribuição e demais condições forem preservadas.

Não importar assets de jogos comerciais, APKs de terceiros, marcas, personagens ou arquivos sem autorização/licença compatível.

Para cada asset externo, registrar em ASSET_MANIFEST.json:
- nome
- origem
- licença
- autor
- URL
- modificado (sim/não)
- redistribuível (sim/não)
- atribuição necessária (sim/não)

Ferramentas oficiais usadas no build são baixadas/instaladas no ambiente de CI; não são redistribuídas neste repositório.
