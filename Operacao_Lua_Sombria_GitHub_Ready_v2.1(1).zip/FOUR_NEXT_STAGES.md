# Quatro próximas etapas — Operação Lua Sombria

## 1. Build cloud primário — Codemagic
- Executa QA.
- Baixa Godot 4.7.2 oficial.
- Prepara templates Android.
- Exporta APK de smoke, APK release e AAB.
- Gera SHA-256.

## 2. Build cloud de redundância — Bitrise
- Usa o mesmo script de build.
- Serve como segundo ambiente independente.
- Entrega os artefatos no Bitrise.

## 3. Build cloud de terceira rota — GitHub Actions
- Ubuntu runner.
- Android SDK 35.
- Java 17.
- Executa o mesmo pipeline.
- Guarda APK/AAB como artifacts.

## 4. Distribuição e validação — Firebase App Distribution
- Recebe o APK de teste.
- Distribui a testadores confiáveis.
- Permite instalar e obter feedback de estabilidade.
- A validação final de hardware deve ocorrer no Samsung A16 real.

### Critério de pronto
O projeto só passa para "release" depois de um CI produzir APK/AAB não vazios e a versão APK ser instalada/testada no dispositivo-alvo.
