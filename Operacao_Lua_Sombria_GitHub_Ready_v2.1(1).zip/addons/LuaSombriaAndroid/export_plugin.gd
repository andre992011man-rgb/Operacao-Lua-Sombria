@tool
extends EditorPlugin

var export_plugin: AndroidExportPlugin

func _enter_tree() -> void:
    export_plugin = AndroidExportPlugin.new()
    add_export_plugin(export_plugin)

func _exit_tree() -> void:
    if export_plugin:
        remove_export_plugin(export_plugin)
        export_plugin = null

class AndroidExportPlugin extends EditorExportPlugin:
    var _plugin_name := "LuaSombriaAndroid"

    func _supports_platform(platform: EditorExportPlatform) -> bool:
        return platform is EditorExportPlatformAndroid

    func _get_android_libraries(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
        var aar := "res://addons/LuaSombriaAndroid/bin/release/LuaSombriaAndroid-release.aar"
        if debug:
            aar = "res://addons/LuaSombriaAndroid/bin/debug/LuaSombriaAndroid-debug.aar"
        if FileAccess.file_exists(aar):
            return PackedStringArray([aar])
        return PackedStringArray()

    func _get_android_dependencies(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
        return PackedStringArray()

    func _get_android_dependencies_maven_repos(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
        return PackedStringArray()

    func _get_android_manifest_element_contents(platform: EditorExportPlatform, debug: bool) -> String:
        return "<uses-permission android:name=\"android.permission.INTERNET\" />"

    func _get_name() -> String:
        return _plugin_name
