# Build Android gratuito — GitHub Actions

O projeto inclui `.github/workflows/android-release.yml`.

## 1. Criar repositório

Envie esta pasta para um repositório GitHub. Para usar o runner padrão sem cobrança, deixe o repositório público; a documentação atual do GitHub informa que GitHub Actions é gratuito para runners padrão em repositórios públicos. Verifique os limites antes de usar armazenamento/execuções em excesso.

## 2. Compilação sem assinatura

Abra **Actions → Operacao Lua Sombria - Android Release → Run workflow**.

O workflow baixa o Godot 4.7.2 estável do domínio oficial de downloads do Godot, instala/valida Android SDK Build Tools e executa a QA e a exportação APK/AAB.

## 3. Assinatura

No GitHub, configure estes **Repository secrets**:

- `ANDROID_KEYSTORE_B64`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_STORE_PASSWORD`

O keystore é decodificado apenas durante o job, usado para assinatura e removido antes do artefato ser publicado.

Para gerar a variável base64 localmente:

```bash
base64 -w 0 release.jks > release.jks.b64
```

No macOS:

```bash
base64 release.jks | tr -d '\n' > release.jks.b64
```

Nunca faça commit do `.jks`, `.p12`, senha ou arquivo `.b64`.

## 4. Artefatos

Depois do job terminar, abra o resumo da execução e baixe o artefato `operacao-lua-sombria-android`.

A versão assinada será `build/ci/signed/OperacaoLuaSombria2074.apk` quando os quatro secrets estiverem configurados.
