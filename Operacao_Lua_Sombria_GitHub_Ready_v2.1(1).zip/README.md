# Operação Lua Sombria — YABA 2074 — v0.6 Cidade Lua

Esta versão concentra a produção em Cidade Lua e adiciona uma camada de conteúdo procedural/produção: distritos, trânsito, NPCs, hospital, polícia, garagem, loja, metrô, sistema de cartões de acesso, sequência de 10 missões iniciais, áudio/vozes de protótipo, música, cinematics e assets 3D detalhados gerados proceduralmente.

## Cartão de acesso
O jogo agora possui cartões de acesso internos. O nível do cartão é persistido no save e é desbloqueado pela sequência de missões. Níveis: 0 sem cartão, 1 civil, 2 policial, 3 militar, 4 comando.

## Conteúdo final
Os assets desta entrega são **conteúdo de produção prototipal**, não um pacote AAA final. Modelos, texturas, vozes, música e cinematics foram gerados para tornar o projeto jogável e substituíveis por conteúdo final de estúdio.

## Godot executável
O ambiente desta sessão não permitiu baixar/incluir o binário do Godot. O projeto aponta para Godot 4.7.2 estável e inclui scripts de preparação Android. O download oficial do editor e templates deve ser feito pela máquina de desenvolvimento.

## Android
Use tools/setup_android_linux.sh ou tools/setup_android_windows.ps1 e depois tools/build_android.sh. O APK só deve ser declarado pronto após exportação real e teste em Galaxy A16.
