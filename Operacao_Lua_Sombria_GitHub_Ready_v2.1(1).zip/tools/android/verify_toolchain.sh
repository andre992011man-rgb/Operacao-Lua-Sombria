#!/usr/bin/env bash
set -euo pipefail
need=(java keytool)
for x in "${need[@]}"; do command -v "$x" >/dev/null || { echo "MISSING:$x"; exit 2; }; done
for x in godot gradle aapt2 zipalign apksigner adb; do if command -v "$x" >/dev/null; then echo "FOUND:$x=$(command -v "$x")"; else echo "MISSING:$x"; fi; done
