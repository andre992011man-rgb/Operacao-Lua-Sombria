#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
"$ROOT/tools/android/verify_toolchain.sh"
if command -v godot >/dev/null; then
  echo 'Godot detected; export using the Android preset with Gradle Build enabled.'
  echo 'APK:  godot --headless --path "$ROOT" --export-release "Android" build/OperacaoLuaSombria2074.apk'
  echo 'AAB:  godot --headless --path "$ROOT" --export-release "Android AAB" build/OperacaoLuaSombria2074.aab'
else
  echo 'Godot not installed in this environment; pipeline prepared, not executed.'
fi
