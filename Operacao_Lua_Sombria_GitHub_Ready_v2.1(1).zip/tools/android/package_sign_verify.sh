#!/usr/bin/env bash
set -euo pipefail
APK="${1:?APK input required}"
OUT="${2:-${APK%.apk}-signed.apk}"
KEYSTORE="${KEYSTORE:?Set KEYSTORE to your own JKS/PKCS12}"
ALIAS="${KEY_ALIAS:?Set KEY_ALIAS}"
KEYPASS="${KEY_PASSWORD:?Set KEY_PASSWORD}"
BUILD_TOOLS="${ANDROID_HOME:-}/build-tools"
if command -v zipalign >/dev/null; then ZIPALIGN=$(command -v zipalign); else ZIPALIGN=$(find "$BUILD_TOOLS" -name zipalign -type f 2>/dev/null | sort -V | tail -1); fi
if command -v apksigner >/dev/null; then APKSIGNER=$(command -v apksigner); else APKSIGNER=$(find "$BUILD_TOOLS" -name apksigner -type f 2>/dev/null | sort -V | tail -1); fi
[ -x "$ZIPALIGN" ] || { echo 'zipalign not found'; exit 3; }
[ -x "$APKSIGNER" ] || { echo 'apksigner not found'; exit 3; }
TMP="${OUT}.aligned"
"$ZIPALIGN" -f -p 4 "$APK" "$TMP"
"$APKSIGNER" sign --ks "$KEYSTORE" --ks-key-alias "$ALIAS" --ks-pass pass:"$KEYPASS" --out "$OUT" "$TMP"
rm -f "$TMP"
"$APKSIGNER" verify --verbose "$OUT"
echo "SIGNED:$OUT"
