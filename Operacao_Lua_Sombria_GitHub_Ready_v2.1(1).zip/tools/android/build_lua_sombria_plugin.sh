#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT/android_plugin"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle não encontrado. Execute em um ambiente Android/Gradle (GABE ou Gradle instalado)." >&2
  exit 2
fi
gradle :plugin:assembleDebug :plugin:assembleRelease
mkdir -p "$ROOT/addons/LuaSombriaAndroid/bin/debug" "$ROOT/addons/LuaSombriaAndroid/bin/release"
cp plugin/build/outputs/aar/plugin-debug.aar "$ROOT/addons/LuaSombriaAndroid/bin/debug/LuaSombriaAndroid-debug.aar"
cp plugin/build/outputs/aar/plugin-release.aar "$ROOT/addons/LuaSombriaAndroid/bin/release/LuaSombriaAndroid-release.aar"
echo "Plugin AARs gerados e copiados para addons/LuaSombriaAndroid/bin/"
