# Build final Android — Operação Lua Sombria

## Rota suportada atualmente
Godot 4.7 Android Editor + GABE.

1. Abra o projeto no Godot Android Editor.
2. Project > Install Android Build Template.
3. Abra GABE e instale o Rootfs.
4. Project > Export > Android.
5. Ative `Use Gradle Build`.
6. ARM64-v8a: ligado; ARMv7: desligado.
7. Renderer: Compatibility/OpenGL3.
8. Gere primeiro Debug APK; depois Release APK/AAB.

## Identidade
- Package: `com.operacaoluasombria.yaba2074`
- Nome: `Operação Lua Sombria 2074`
- Versão: `0.5.2074`

## Antes de publicar
- trocar URLs vazias do manifesto por servidor real;
- definir SHA-256 dos pacotes;
- configurar keystore de release;
- testar instalação, atualização, save/restore e retomada após fechar o app;
- testar fisicamente no Galaxy A16.
