#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/tests/test_project.py"
if command -v godot >/dev/null 2>&1; then
  godot --headless --path "$ROOT" --editor --quit-after 3
  godot --headless --path "$ROOT" --script res://tests/smoke_test.gd
elif command -v godot4 >/dev/null 2>&1; then
  godot4 --headless --path "$ROOT" --editor --quit-after 3
  godot4 --headless --path "$ROOT" --script res://tests/smoke_test.gd
else
  echo "AVISO: Godot CLI não instalado; somente QA estática executada."
fi
