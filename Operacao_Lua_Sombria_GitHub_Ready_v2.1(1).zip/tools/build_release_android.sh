#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GODOT="${GODOT_BIN:-$ROOT/tools/godot/godot}"
if [ ! -x "$GODOT" ]; then echo "Godot executable missing. Run tools/fetch_godot_4_7_2.sh on a networked machine."; exit 10; fi
if [ -z "${ANDROID_SDK_ROOT:-}" ]; then echo "ANDROID_SDK_ROOT is not set."; exit 11; fi
mkdir -p "$ROOT/build/android"
"$GODOT" --headless --path "$ROOT" --export-release "Android" "$ROOT/build/android/OperacaoLuaSombria2074.apk"
echo "APK: $ROOT/build/android/OperacaoLuaSombria2074.apk"
