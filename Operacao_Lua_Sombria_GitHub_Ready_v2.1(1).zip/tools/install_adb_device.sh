#!/usr/bin/env bash
set -euo pipefail
ADB_BIN="${ADB_BIN:-adb}"
if ! command -v "$ADB_BIN" >/dev/null 2>&1; then
  echo "adb nao encontrado. Configure o Android SDK primeiro."; exit 2
fi
"$ADB_BIN" start-server
"$ADB_BIN" devices -l
cat <<'TXT'

Para teste USB no Galaxy A16:
1. Ative Opcoes do desenvolvedor e Depuracao USB no aparelho.
2. Conecte por USB e aceite a chave RSA.
3. Rode: adb devices -l
4. Rode o APK debug/release desejado pelo Godot.

O teste fisico deve medir FPS, stutter, memoria, temperatura, bateria, touch e travamentos.
TXT
