#!/usr/bin/env bash
set -euo pipefail
# Android build bootstrap. Requires network access and a compatible JDK.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_SDK_ROOT:-$ROOT/.android-sdk}"
TOOLS="$SDK/cmdline-tools/latest"
mkdir -p "$SDK/cmdline-tools"
if [ ! -x "$TOOLS/bin/sdkmanager" ]; then
  echo "Install Android command-line tools into $SDK/cmdline-tools/latest first."
  echo "Official source: https://developer.android.com/studio#command-line-tools-only"
  exit 2
fi
export ANDROID_SDK_ROOT="$SDK"
export PATH="$TOOLS/bin:$SDK/platform-tools:$SDK/build-tools/35.0.0:$PATH"
sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"
if command -v java >/dev/null 2>&1; then java -version; else echo 'JDK not found'; exit 3; fi
adb version
