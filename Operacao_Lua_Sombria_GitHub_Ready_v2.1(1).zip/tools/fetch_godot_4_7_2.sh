#!/usr/bin/env bash
set -euo pipefail
# Downloads the official Godot 4.7.2 editor when network access is available.
# This environment cannot bundle the binary itself because external downloads are disabled.
URL="https://github.com/godotengine/godot/releases/download/4.7.2-stable/Godot_v4.7.2-stable_linux.x86_64.zip"
OUT="tools/Godot_v4.7.2-stable_linux.x86_64.zip"
mkdir -p tools/godot
if command -v curl >/dev/null 2>&1; then curl -L "$URL" -o "$OUT"; else wget -O "$OUT" "$URL"; fi
unzip -o "$OUT" -d tools/godot
chmod +x tools/godot/Godot_v4.7.2-stable_linux.x86_64
ln -sf Godot_v4.7.2-stable_linux.x86_64 tools/godot/godot
