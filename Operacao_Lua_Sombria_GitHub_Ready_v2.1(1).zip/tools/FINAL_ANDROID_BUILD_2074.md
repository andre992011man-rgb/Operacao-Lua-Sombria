# Operação Lua Sombria 2074 — build Android moderno

## Projeto
- Godot alvo: 4.7
- Renderizador: Compatibility / OpenGL ES
- Arquitetura principal: ARM64-v8a
- Package: `com.operacaoluasombria.yaba2074`
- Versão: `0.6.2074`
- APK: `build/OperacaoLuaSombria2074.apk`
- AAB: `build/OperacaoLuaSombria2074.aab`

## O que foi modernizado
- Runtime Android próprio com ciclo de vida.
- Monitor local de FPS/memória e perfil de economia de energia.
- Ponte opcional para Android singleton/plugin.
- Feature flags, notices, cache, download, update, save recovery e diagnóstico.
- Gradle habilitado.
- Target SDK 35 e min SDK 24.
- Preset APK e preset AAB.

## Compilação no Android
1. Abrir o projeto no Godot 4.7 Android Editor.
2. Instalar o Android Build Template.
3. Abrir GABE.
4. `Rootfs` -> `Install Rootfs`.
5. Em `Project -> Export`, usar `Android A16 2074` para APK.
6. Para loja, usar `Android A16 Release AAB`.
7. Para publicação, configurar um keystore de release próprio e desativar debug.

## Observação
O projeto pode ser preparado e validado estaticamente fora do Godot, mas a criação do binário APK/AAB exige que Godot/GABE execute a compilação. Não há keystore privado incluído.
