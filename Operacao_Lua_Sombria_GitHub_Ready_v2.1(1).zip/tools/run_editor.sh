#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if command -v godot >/dev/null 2>&1; then
  exec godot --editor "$ROOT/project.godot"
elif command -v godot4 >/dev/null 2>&1; then
  exec godot4 --editor "$ROOT/project.godot"
else
  echo "Godot 4.7.2 não está instalado nesta máquina."
  echo "Baixe o editor oficial em: https://godotengine.org/download/archive/4.7.2-stable/"
  exit 2
fi
