#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GODOT_BIN="${GODOT_BIN:-godot}"
OUT_DIR="$ROOT/build"
mkdir -p "$OUT_DIR"

if ! command -v "$GODOT_BIN" >/dev/null 2>&1; then
  echo "Godot CLI nao encontrado. Defina GODOT_BIN=/caminho/para/godot ou instale o Godot."
  exit 2
fi

if [[ -z "${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}" ]]; then
  echo "ANDROID_SDK_ROOT/ANDROID_HOME nao definido."
  exit 3
fi

"$GODOT_BIN" --headless --path "$ROOT" --editor --quit-after 3
"$GODOT_BIN" --headless --path "$ROOT" --export-release "Android A16 2074" "$OUT_DIR/OperacaoLuaSombria2074.apk"
ls -lh "$OUT_DIR/OperacaoLuaSombria2074.apk"
