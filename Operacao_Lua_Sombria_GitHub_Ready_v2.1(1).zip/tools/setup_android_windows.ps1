$ErrorActionPreference = 'Stop'
# Bootstrap local. Instale Android Command-line Tools antes de executar.
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Sdk = $env:ANDROID_SDK_ROOT
if ([string]::IsNullOrWhiteSpace($Sdk)) { $Sdk = "$env:LOCALAPPDATA\Android\Sdk" }
$SdkManager = Join-Path $Sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
if (!(Test-Path $SdkManager)) {
  throw "sdkmanager.bat nao encontrado em $SdkManager"
}
& $SdkManager "platform-tools" "platforms;android-34" "build-tools;34.0.0" "cmdline-tools;latest"
& $SdkManager --licenses
Write-Host "Android SDK: $Sdk"
Write-Host "Projeto: $Root"
Write-Host "Instale/configure OpenJDK 17 para builds Gradle."
