#!/usr/bin/env bash
set -euo pipefail
APK="${1:-build/android/OperacaoLuaSombria2074.apk}"
adb wait-for-device
adb install -r "$APK"
adb shell am force-stop com.operacaoluasombria.yaba2074 || true
adb shell monkey -p com.operacaoluasombria.yaba2074 1
sleep 8
adb shell dumpsys meminfo com.operacaoluasombria.yaba2074 | head -80
adb logcat -d -t 400 | grep -E "Operacao|Godot|FATAL|ERROR" || true
