#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/build/ci"
mkdir -p "$OUT"
: "${GODOT_BIN:=godot}"
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [[ -z "$ANDROID_HOME" ]]; then echo 'ANDROID_HOME/ANDROID_SDK_ROOT ausente'; exit 2; fi
command -v "$GODOT_BIN" >/dev/null || { echo 'Godot ausente'; exit 2; }
command -v sdkmanager >/dev/null || { echo 'sdkmanager ausente'; exit 2; }
"$GODOT_BIN" --version
sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0" >/dev/null
"$GODOT_BIN" --headless --path "$ROOT" --export-release "Android A16 2074" "$OUT/OperacaoLuaSombria2074-unsigned.apk"
"$GODOT_BIN" --headless --path "$ROOT" --export-release "Android A16 Release AAB" "$OUT/OperacaoLuaSombria2074.aab"
echo "APKs/AABs gerados em $OUT"
