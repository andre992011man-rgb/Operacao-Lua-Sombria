#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
APK="${APK_PATH:-$ROOT/build/ci/OperacaoLuaSombria2074-unsigned.apk}"
APP_ID="${FIREBASE_APP_ID:-}"
GROUPS="${FIREBASE_TESTER_GROUPS:-}"

if [[ -z "$APP_ID" || -z "$GROUPS" ]]; then
  echo "Configure FIREBASE_APP_ID e FIREBASE_TESTER_GROUPS no CI antes de distribuir." >&2
  exit 2
fi
if [[ ! -s "$APK" ]]; then
  echo "APK não encontrado: $APK" >&2
  exit 3
fi

command -v firebase >/dev/null || { echo "Firebase CLI ausente" >&2; exit 2; }
firebase appdistribution:distribute "$APK" \
  --app "$APP_ID" \
  --groups "$GROUPS" \
  --release-notes "Operação Lua Sombria - Android 2074 - build cloud"
