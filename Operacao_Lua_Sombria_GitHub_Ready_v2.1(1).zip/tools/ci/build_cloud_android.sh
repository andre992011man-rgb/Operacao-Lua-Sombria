#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
GODOT_VERSION="${GODOT_VERSION:-4.7.2}"
TEMPLATES_VERSION="${GODOT_VERSION}.stable"

: "${ANDROID_SDK_ROOT:=${ANDROID_HOME:-}}"
if [[ -z "${ANDROID_SDK_ROOT}" ]]; then
  echo "ANDROID_SDK_ROOT/ANDROID_HOME não configurado." >&2
  exit 2
fi
export ANDROID_HOME="$ANDROID_SDK_ROOT"

mkdir -p "$ROOT/.ci/godot" "$ROOT/.ci/templates"
cd "$ROOT"

download_official() {
  curl -fL --retry 4 --retry-delay 2 "$1" -o "$2"
}

OS="$(uname -s)"
ARCH="$(uname -m)"

if [[ "$OS" == "Darwin" ]]; then
  GODOT_URL="https://downloads.godotengine.org/?flavor=stable&platform=macos.universal&slug=macos.universal.zip&version=${GODOT_VERSION}"
else
  GODOT_URL="https://downloads.godotengine.org/?flavor=stable&platform=linux.x86_64&slug=linux.x86_64.zip&version=${GODOT_VERSION}"
fi
TEMPLATE_URL="https://downloads.godotengine.org/?flavor=stable&platform=templates&slug=export_templates.tpz&version=${GODOT_VERSION}"

download_official "$GODOT_URL" "$ROOT/.ci/godot/godot.zip"
download_official "$TEMPLATE_URL" "$ROOT/.ci/templates/templates.tpz"

rm -rf "$ROOT/.ci/godot/unpacked" "$ROOT/.ci/templates/unpacked"
mkdir -p "$ROOT/.ci/godot/unpacked" "$ROOT/.ci/templates/unpacked"
unzip -q "$ROOT/.ci/godot/godot.zip" -d "$ROOT/.ci/godot/unpacked"
unzip -q "$ROOT/.ci/templates/templates.tpz" -d "$ROOT/.ci/templates/unpacked"

if [[ "$OS" == "Darwin" ]]; then
  GODOT_BIN="$(find "$ROOT/.ci/godot/unpacked" -type f -path '*/Godot.app/Contents/MacOS/Godot' | head -n1)"
else
  GODOT_BIN="$(find "$ROOT/.ci/godot/unpacked" -type f -name 'Godot_v*-linux.x86_64' | head -n1)"
fi
test -n "$GODOT_BIN"
chmod +x "$GODOT_BIN"

EXPORT_DIR="$HOME/.local/share/godot/export_templates/${TEMPLATES_VERSION}"
rm -rf "$EXPORT_DIR"
mkdir -p "$EXPORT_DIR"
cp -R "$ROOT/.ci/templates/unpacked/." "$EXPORT_DIR/"

echo "Godot:"
"$GODOT_BIN" --version
echo "Android SDK: $ANDROID_HOME"

python3 tests/test_project.py

mkdir -p build/ci
export GODOT_BIN ANDROID_HOME

echo "== Smoke export APK =="
"$GODOT_BIN" --headless --path "$ROOT" --export-debug "Android A16 2074" "$ROOT/build/ci/OperacaoLuaSombria2074-debug.apk"

echo "== Release exports APK + AAB =="
"$ROOT/tools/ci/build_release_github.sh"

for f in "$ROOT/build/ci/OperacaoLuaSombria2074-debug.apk" \
         "$ROOT/build/ci/OperacaoLuaSombria2074-unsigned.apk" \
         "$ROOT/build/ci/OperacaoLuaSombria2074.aab"; do
  test -s "$f" || { echo "Artefato vazio/ausente: $f" >&2; exit 3; }
done
sha256sum build/ci/*.apk build/ci/*.aab > build/ci/SHA256SUMS.txt

# Handoff para os serviços de CI que esperam artefatos no diretório de deploy.
if [[ -n "${BITRISE_DEPLOY_DIR:-}" ]]; then
  mkdir -p "$BITRISE_DEPLOY_DIR"
  cp -f build/ci/*.apk build/ci/*.aab "$BITRISE_DEPLOY_DIR/" 2>/dev/null || true
fi

{
  echo "project=Operação Lua Sombria"
  echo "godot=$("$GODOT_BIN" --version)"
  echo "package=com.operacaoluasombria.yaba2074"
  echo "version_name=0.6.2074"
  echo "version_code=6"
  echo "artifacts=APK,AAB"
  echo "qa=tests/test_project.py"
} > build/ci/build-manifest.txt

echo "artifact_validation=PASS" >> build/ci/build-manifest.txt
echo "Cloud build concluído:"
find build/ci -maxdepth 1 -type f -printf '%f\n' 2>/dev/null || find build/ci -maxdepth 1 -type f -print
