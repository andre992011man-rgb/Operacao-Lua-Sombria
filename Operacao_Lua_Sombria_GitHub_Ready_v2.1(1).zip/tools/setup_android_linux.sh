#!/usr/bin/env bash
set -euo pipefail
# Bootstrap local de Android SDK/ADB/JDK para exportar o projeto.
# Nao baixa nada neste pacote para manter licencas/tamanho sob controle.
# Requer que o Android command-line tools ja estejam instalados e que sdkmanager esteja no PATH.

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
export ANDROID_HOME ANDROID_SDK_ROOT="$ANDROID_HOME"

if ! command -v sdkmanager >/dev/null 2>&1; then
  echo "sdkmanager nao encontrado. Instale Android Command-line Tools e adicione cmdline-tools/latest/bin ao PATH."
  exit 2
fi

sdkmanager --sdk_root="$ANDROID_HOME" \
  "platform-tools" \
  "platforms;android-34" \
  "build-tools;34.0.0" \
  "cmdline-tools;latest"

SDKMANAGER_ACCEPTED=0
yes | sdkmanager --licenses >/dev/null 2>&1 || true
if command -v adb >/dev/null 2>&1; then
  adb version
else
  echo "ADB ainda nao esta no PATH. Use: $ANDROID_HOME/platform-tools/adb"
fi

if command -v java >/dev/null 2>&1; then
  java -version
else
  echo "Java nao encontrado. Para exportacao Gradle, instale OpenJDK 17."
fi

echo "Android SDK preparado em: $ANDROID_HOME"
echo "Projeto: $ROOT"
