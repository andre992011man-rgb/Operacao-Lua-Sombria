@echo off
set ROOT=%~dp0..\
if exist "%ProgramFiles%\Godot\godot.exe" (
  "%ProgramFiles%\Godot\godot.exe" --editor "%ROOT%project.godot"
  exit /b 0
)
where godot.exe >nul 2>nul && godot.exe --editor "%ROOT%project.godot" && exit /b 0
echo Godot 4.7.2 nao encontrado. Baixe em https://godotengine.org/download/archive/4.7.2-stable/
exit /b 2
