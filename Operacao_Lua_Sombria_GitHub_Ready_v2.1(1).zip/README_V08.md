# Operação Lua Sombria 2074 — v0.8 YABA Combat & City Life

Esta versão amplia a v0.7 com animação articulada de YABA, IA de combate com cobertura/flanqueamento/reforços, física de veículos, vida urbana, 100 props de Cidade Lua, PBR maps protótipos, áudio ambiente adicional, cinematics de missão e scripts de toolchain Android/Godot.

**Estado:** protótipo jogável Godot; não é APK final.

### Controles
WASD mover · Shift correr · Espaço ação/tiro · E interagir · C mirar · R recarregar · Q trocar arma · B frear veículo · M mapa · V veículo · F scanner · G drone · I kit.

### Build Android
1. Instale Godot 4.7.2 e export templates.
2. Configure JDK/Android SDK/ADB.
3. Execute `tools/build_release_android.sh`.
4. Conecte o Galaxy A16 por ADB e execute `tools/test_device_a16.sh`.

Os scripts não substituem os binários do SDK/Godot e não foram executados nesta sessão porque o ambiente não tem a toolchain instalada.
