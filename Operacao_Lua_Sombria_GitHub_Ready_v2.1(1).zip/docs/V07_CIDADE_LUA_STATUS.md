# v0.7 — Cidade Lua 2074

## Criado nesta etapa
- trânsito visual com hovercars em rotas
- IA policial com níveis de alerta
- combate separado em sistema reutilizável
- serviços de loja, garagem, hospital, metrô e delegacia
- interiores modulares para apartamento, polícia, hospital, garagem e metrô
- 10 missões iniciais com objetivos sequenciais
- sequência cinematográfica textual/áudio controlada por script
- novos props 3D: semáforo, terminal, porto de drones e painel neon
- integração de NPCs, trânsito, polícia e missão no runtime principal

## Ainda não é final AAA
Os assets 3D adicionados são protótipos procedurais. O projeto ainda precisa de arte final, rigging, animações esqueléticas, captura/produção de voz, trilha final, efeitos sonoros finais, cinematics renderizadas, mapa autoral detalhado e testes reais em Galaxy A16.

## APK
Não compilado nesta sessão: o ambiente não possui executável Godot/Android SDK/JDK configurados. Scripts de setup/export continuam no projeto.
