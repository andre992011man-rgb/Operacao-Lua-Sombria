# Próximas expansões possíveis

## Conteúdo
- 200+ missões secundárias;
- facções e reputação por região;
- NPCs com árvores de diálogo;
- mais interiores visitáveis;
- colecionáveis e segredos;
- rádio dinâmica;
- eventos raros;
- bosses e confrontos especiais.

## Tecnologia
- multiplayer/co-op;
- replay e gravação de clipes;
- sincronização em nuvem;
- sistema de mods;
- localização multilíngue;
- suporte a controle Bluetooth;
- vibração háptica;
- benchmark automático;
- crash recovery;
- atualização incremental de conteúdo.

## Arte
- personagens humanos com rig completo;
- veículos com interior;
- destruição controlada;
- VFX finais;
- água e partículas;
- iluminação final;
- materiais PBR finais;
- cinematics com captura de movimento.
