# v0.8 — YABA Combat & City Life

## Implementado nesta etapa
- YABA articulated runtime animation state machine: idle, walk, run, crouch, aim, fire, reload, weapon swap, damage, fall, death, enter/exit vehicle, zero-G.
- Enemy combat AI with cover seeking, flanking, pursuit, reload, localized damage and reinforcement requests.
- Vehicle controller with braking, collision-impact damage, integrity, fuel, engine temperature and wheel-spin state.
- City-life director with random incidents and police dispatch metadata.
- 100 modular Cidade Lua GLB props across apartments, shops, restaurants, furniture, machines, signs, trees, roofs, metro and interiors.
- Additional prototype audio layers: footsteps, rain, wind, explosion, combat, hover-engine and investigation.
- 10 cinematic mission beat definitions.
- Android/Godot bootstrap scripts and A16 device test script.

## Não implementado como produção final
- Official Godot executable binary: cannot be bundled in this session because external binary downloads are unavailable.
- Android SDK/ADB binaries: same limitation; scripts are included.
- Professional human voice acting / lip-sync: current voice assets are prototype synthesized/processed audio.
- Final AAA skeletal animation rig: current YABA animation is articulated runtime animation over named GLB parts; a skinned rig can replace it later.
- Final photoreal/PBR art: generated props are lightweight production-layout prototypes.
- Real Galaxy A16 hardware testing: requires a physical device/ADB host.

## Jogabilidade
The project is a playable Godot prototype when opened with a compatible Godot 4.x editor. It is not a finished commercial APK.
