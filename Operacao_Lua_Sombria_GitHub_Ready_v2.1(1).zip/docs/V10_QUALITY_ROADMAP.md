# Operação Lua Sombria — V1.0 / Meta de qualidade 100

Esta versão adiciona sistemas de acabamento e uma matriz de validação. “Nota 100” é uma meta de produção, não uma nota já comprovada.

## Novos sistemas
- qualidade adaptativa;
- acessibilidade;
- conquistas;
- crafting;
- eventos dinâmicos por mundo;
- Photo Mode;
- matriz de conclusão;
- dados de perfil Low/A16/High.

## Para chegar ao nível comercial
1. Instalar Godot 4.x e exportar Android.
2. Instalar Android SDK/ADB.
3. Compilar APK/AAB.
4. Rodar no Galaxy A16 físico.
5. Medir FPS, RAM, temperatura, bateria e tempo de carregamento.
6. Corrigir travamentos, colisões, navegação, missões e regressões.
7. Trocar modelos protótipos por arte final.
8. Fazer rig esquelético profissional de YABA e animações finais.
9. Gravar vozes humanas e lip-sync.
10. Fazer mixagem/masterização de áudio e efeitos finais.
11. Fazer testes de usabilidade, acessibilidade e controles touch.
12. Fazer QA de todas as 100 missões e de todos os mundos.
13. Otimizar o pacote final e validar instalação/atualização.
