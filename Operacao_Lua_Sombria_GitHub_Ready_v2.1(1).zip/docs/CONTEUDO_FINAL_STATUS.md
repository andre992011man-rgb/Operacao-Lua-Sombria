# Status de conteúdo — v0.6

Esta entrega adiciona conteúdo de produção prototipal real (modelos GLB, texturas PNG, vozes sintetizadas em português, trilhas WAV e cenas de cinematic controladas por código).

Não é correto chamar esse material de conteúdo final AAA: vozes de elenco, música masterizada, animações esqueléticas, captura facial, cinematics renderizadas e mapas artísticos detalhados ainda exigem produção de estúdio.

O objetivo desta etapa é deixar o jogo funcional e a pipeline pronta para substituir cada asset por sua versão final sem reescrever o gameplay.
