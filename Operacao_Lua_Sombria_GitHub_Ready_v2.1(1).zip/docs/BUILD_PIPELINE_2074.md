# Build pipeline 2074

1. Build the own Android v2 plugin with `tools/android/build_lua_sombria_plugin.sh` in an environment containing Gradle + Android SDK.
2. The resulting AARs are copied to `addons/LuaSombriaAndroid/bin/{debug,release}`.
3. Godot Gradle export includes the AAR through `EditorExportPlugin`.
4. Export preset remains ARM64 + Gradle APK/AAB.
5. Sign release with the project's own keystore.

The reference APK is not used as a binary component. No private keys, certificates, credentials, tokens, private endpoints, DRM, protected assets, or non-redistributable libraries are included.
