# Toolchain Android

O projeto agora inclui scripts para preparar o ambiente Android, mas **o SDK/ADB/Godot nao sao incorporados ao ZIP**. Sao ferramentas externas licenciadas e pesadas; alem disso, o ambiente atual de criacao nao possui rede para baixar esses pacotes.

Para uma maquina de build, configure:

- Godot 4.x compativel com o projeto;
- OpenJDK 17 para builds Gradle;
- Android SDK;
- Android Platform Tools (`adb`);
- export templates Android da mesma versao do Godot;
- opcionalmente NDK/CMake se houver build nativo personalizado.

O script `tools/setup_android_linux.sh` instala os componentes de SDK via `sdkmanager` quando ele ja estiver disponivel.

O fluxo e:

`setup_android -> QA estatica -> Godot headless smoke -> export APK -> adb install -> teste fisico -> release`

A documentacao oficial do Godot recomenda JDK 17 para compatibilidade/estabilidade e configura o Android SDK contendo `platform-tools/adb`. Para versões recentes do Godot, a propria interface pode oferecer setup automatico do Android/Java SDK. Consulte a documentacao da versao exata usada no projeto. 
