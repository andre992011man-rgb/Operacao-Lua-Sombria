# Operação Lua Sombria — Android/Gradle 2074

Esta camada implementa em código próprio funções Android equivalentes às necessidades do jogo: ciclo de vida, avisos, permissões, diagnóstico e eventos locais.

## Origem e licenciamento
Nenhuma chave privada, certificado de terceiros, credencial, token, endpoint privado, DRM, asset proprietário ou biblioteca sem licença de redistribuição é incluída. O APK de referência serve somente como referência funcional.

## Plugin v2
`android_plugin/` é um módulo Android Gradle que depende da biblioteca Android do Godot 4.7. O resultado AAR é copiado para `addons/LuaSombriaAndroid/bin/` e o `EditorExportPlugin` o injeta no export Android.

## Build do plugin
Use um ambiente com Gradle/Android SDK (GABE é uma opção quando o build é executado pelo editor Android):
`tools/android/build_lua_sombria_plugin.sh`

Depois, o projeto usa `Use Gradle Build` para o APK/AAB.

## Segurança
Assinatura de release deve usar um keystore próprio do projeto. Nunca reutilize certificados/chaves do APK de referência.
