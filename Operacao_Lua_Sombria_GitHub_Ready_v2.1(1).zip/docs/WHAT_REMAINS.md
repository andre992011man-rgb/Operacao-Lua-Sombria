# O que ainda falta para o jogo comercial

## Já jogável
Sim, como protótipo Godot: personagem, movimento, combate básico, missões, veículos, NPCs, polícia, interiores, lojas/serviços, scanner, drone, trânsito e Cidade Lua estão estruturados.

## Ainda não é uma versão final
1. Godot editor/binário oficial dentro do pacote — indisponível neste ambiente por falta de download externo.
2. Android SDK/ADB binários — scripts de instalação incluídos, binários não embutidos.
3. APK/AAB real — requer toolchain Android e exportação.
4. Teste físico no Galaxy A16 — requer aparelho conectado por ADB.
5. Rig esquelético profissional de YABA e captura/produção de animações finais. A v0.8 usa animação articulada real por partes do GLB.
6. Arte 3D final/AAA. Os 100 props novos são assets modulares leves para produção/greybox avançado.
7. Voz humana profissional e sincronização labial. As vozes atuais são protótipos.
8. Física de veículo AAA; o sistema móvel já possui aceleração, frenagem, colisão, integridade, combustível e temperatura.
9. Iluminação/efeitos finais e pós-processamento.
10. Balanceamento das 100 missões e QA de regressão em hardware real.
11. Multiplayer, se for desejado; o projeto atual é solo.
12. Conteúdo real de ~3 GB. O orçamento de 3 GB existe, mas não é preenchido artificialmente.

## Próxima prioridade
Finalizar rig/animações de YABA, combate/IA em profundidade, mapa autoral detalhado de Cidade Lua, cinematics das 10 missões, áudio/vozes profissionais e depois exportar/testar no A16.
