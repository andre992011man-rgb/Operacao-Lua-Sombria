# Operação Lua Sombria — próximos passos de produção

## Já implementado no protótipo
- YABA em terceira pessoa
- mundo procedural com ruas, prédios e props
- NPCs civis/inimigos
- combate por raycast e munição
- 100 missões estruturadas
- viagem entre regiões
- veículo procedural de teste
- inventário/kit médico
- save/load
- ciclo dia/noite e clima
- HUD e controles touch
- gerenciador de performance visando 30 FPS

## Para a versão visual completa
1. Substituir cápsula do YABA por personagem 3D rigado.
2. Criar/importar animações: idle, walk, run, aim, fire, hit, death, enter/exit vehicle.
3. Criar kits de prédios, interiores, estradas, vegetação, veículos e armas.
4. Produzir mapas por setores para Cidade Lua, Cidade Nova, Porto Velho etc.
5. Criar sistemas de tráfego e pedestres com pooling.
6. Implementar veículos dirigíveis com física simplificada.
7. Implementar naves e transição órbita/planeta.
8. Produzir áudio final e diálogos.
9. Testar memória/temperatura/FPS no Galaxy A16 real.
10. Exportar APK/AAB com Godot + Android SDK/JDK.

## Limitação desta etapa
Este ambiente não possui o toolchain Godot/Android configurado, então não é possível declarar um APK nativo compilado/testado aqui. O projeto, scripts e estrutura estão prontos para abertura no Godot e para o ciclo de build Android.
