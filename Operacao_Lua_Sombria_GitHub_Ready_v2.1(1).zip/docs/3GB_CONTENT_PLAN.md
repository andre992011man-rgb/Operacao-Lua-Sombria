# Plano de conteudo de 3 GB — Operacao Lua Sombria 2074

## Importante

3 GB deve ser tratado como **orcamento de conteudo**, nao como enchimento artificial do projeto. Criar um arquivo vazio ou lixo comprimido para atingir 3 GB nao melhora o jogo.

O projeto atual permanece pequeno porque os modelos e sons sao prototipos procedurais. O crescimento real deve vir de:

- modelos 3D finais de personagens, veiculos, armas, interiores e props;
- texturas PBR comprimidas e variantes de qualidade;
- animacoes e mocap;
- musica, vozes e efeitos;
- cenas de cidades e planetas;
- cinemáticas;
- localizacao;
- shaders e UI.

## Distribuicao alvo

| Categoria | Orcamento |
|---|---:|
| Modelos 3D | 768 MiB |
| Texturas | 1 GiB |
| Audio | 512 MiB |
| Animacoes | 256 MiB |
| Dados de mundo | 256 MiB |
| UI/fontes/shaders | 128 MiB |
| Missoes/localizacao | 64 MiB |
| Reserva de streaming | 128 MiB |
| **Total** | **3 GiB** |

## Regra para o Galaxy A16

O tamanho instalado e a memoria RAM sao problemas diferentes. Mesmo que o jogo tenha 3 GB de conteudo instalado, o aparelho nao deve carregar esses 3 GB de uma vez.

A arquitetura deve manter somente:

- setor atual;
- setor vizinho;
- texturas/LOD necessarios;
- NPCs proximos;
- audio local;
- dados da missao ativa.

Planetas, cidades e estacoes devem ser cenas/pacotes independentes.
