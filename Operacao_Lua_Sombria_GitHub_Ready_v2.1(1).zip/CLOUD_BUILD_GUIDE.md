# Operação Lua Sombria — pipeline em sites de primeira linha

## Estado verificado antes do envio
- Projeto Godot: 4.7.x configurado no `project.godot`.
- Presets Android: APK e AAB.
- Arquitetura Android: ARM64.
- SDK alvo configurado: Android 35.
- QA estática local: **87 verificações / 0 falhas**.
- O projeto contém workflow de CI e script de exportação.

## Pipeline em nuvem

### 1. Codemagic
Site: https://codemagic.io/

1. Crie/acesse sua conta.
2. Conecte o repositório deste projeto.
3. Confirme que `codemagic.yaml` está na raiz.
4. Selecione `lua-sombria-android-cloud`.
5. Execute o build.
6. Baixe os artefatos APK/AAB na página do build.

O workflow baixa o Godot 4.7.2 pelos endpoints oficiais do Godot e instala os templates de exportação antes de executar o QA e o export.

### 2. Bitrise
Site: https://bitrise.io/

1. Conecte o mesmo repositório.
2. Use `bitrise.yml`.
3. Execute `lua_sombria_android_cloud`.
4. O artefato será armazenado no Bitrise após o build.

Isso fornece uma segunda infraestrutura independente para validar a mesma versão do projeto.

### 3. Firebase App Distribution
Site: https://firebase.google.com/

Depois de uma build bem-sucedida:
1. Crie/registre o app Android usando o package name:
   `com.operacaoluasombria.yaba2074`
2. Abra App Distribution.
3. Envie a build de teste.
4. Adicione os testadores.
5. Use o link de teste no Samsung A16.

### 4. Google Play Console
Site: https://play.google.com/console/

Para publicação, use o **AAB de release** e a assinatura de lançamento. Não coloque chaves privadas no repositório.

## Segurança
- Nunca coloque `.jks`, senhas, JSON de service account ou chaves privadas no repositório.
- Use os Secrets/Code Signing de Codemagic ou Bitrise.
- O primeiro build deve ser validado antes de automatizar publicação.

## Observação
Os serviços externos exigem que o proprietário faça login e autorize o repositório. Este pacote já prepara a configuração, mas não autentica nem inicia builds em contas externas automaticamente.


## Gate de conclusão real

O pacote está preparado para build em nuvem, mas “compilado” só significa concluído quando Codemagic ou Bitrise retornar os artefatos APK e AAB sem erro. A etapa seguinte exige conectar o repositório a um desses serviços e iniciar o workflow.

O pipeline v1.9:
- valida o projeto com `tests/test_project.py`;
- instala o Godot 4.7.2 estável e os templates oficiais;
- usa Android SDK/Build Tools 35;
- gera APK e AAB;
- entrega os artefatos ao diretório de deploy do Bitrise quando esse ambiente existir;
- gera `build-manifest.txt` para registrar versão e artefatos.

A distribuição para testers pode ser feita depois pelo Firebase App Distribution, e a publicação em Google Play requer as credenciais e assinatura da conta do desenvolvedor.
