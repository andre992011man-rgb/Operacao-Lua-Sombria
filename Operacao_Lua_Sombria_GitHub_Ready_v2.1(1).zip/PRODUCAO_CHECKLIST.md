# Checklist de producao — Operacao Lua Sombria 2074 v0.6

## Base tecnica
- [x] Godot project
- [x] Android ARM64 export preset
- [x] Compatibility/OpenGL
- [x] Perfil adaptativo A16
- [x] Streaming por distancia preparado
- [x] Telemetria de QA
- [x] 100 missoes
- [x] 23 mundos/regioes

## Sistemas 2074
- [x] Exotraje YABA
- [x] Scanner
- [x] Drone
- [x] IA de ameaca
- [x] Rotina de NPC
- [x] Base de trafego
- [x] Loja
- [x] Upgrades
- [x] Veiculos prototipos
- [x] Interiores prototipos

## QA
- [x] Teste de integridade Python
- [x] Smoke test Godot
- [x] Matriz de 5 testadores
- [x] Telemetria de frame/node
- [ ] Teste real no Galaxy A16
- [ ] Teste de temperatura/bateria
- [ ] Teste de touch prolongado
- [ ] Teste de memoria/oom
- [ ] Teste de retomada apos segundo plano

## Conteudo 3 GB
- [x] Orcamento de 3 GiB documentado
- [ ] Modelos finais rigados
- [ ] Texturas PBR finais
- [ ] LODs finais
- [ ] Animacoes completas
- [ ] Vozes
- [ ] Musicas finais
- [ ] Cinematicas
- [ ] Ambientes finais de todas as regioes

## Android toolchain
- [x] scripts de setup SDK/ADB
- [x] script de build Android
- [x] preset ARM64
- [ ] Godot CLI instalado na maquina de build
- [ ] Export templates da mesma versao
- [ ] Android SDK instalado
- [ ] OpenJDK 17 configurado
- [ ] ADB reconhecendo aparelho
- [ ] APK debug instalado
- [ ] APK release assinado
- [ ] AAB de release
