extends CanvasLayer
class_name DialogueSystem
var panel:ColorRect
var label:Label
var speaker_label:Label
var visible_dialogue:=false

func _ready():
    panel=ColorRect.new(); panel.position=Vector2(60,520); panel.size=Vector2(1160,145); panel.color=Color(0.01,0.03,0.07,0.94); add_child(panel)
    speaker_label=Label.new(); speaker_label.position=Vector2(24,16); speaker_label.add_theme_font_size_override("font_size",18); panel.add_child(speaker_label)
    label=Label.new(); label.position=Vector2(24,50); label.size=Vector2(1110,80); label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; label.add_theme_font_size_override("font_size",22); panel.add_child(label)
    panel.visible=false

func show_line(speaker:String,text:String):
    panel.visible=true; visible_dialogue=true; speaker_label.text=speaker; label.text=text

func clear_line():
    panel.visible=false; visible_dialogue=false
