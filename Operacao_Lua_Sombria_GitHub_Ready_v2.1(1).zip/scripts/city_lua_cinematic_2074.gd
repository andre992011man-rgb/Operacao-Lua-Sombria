class_name CityLuaCinematic2074
extends Node

signal finished
var running := false
var timer := 0.0
var step := 0
var lines := [
    "Central: YABA, Cidade Lua entrou em alerta.",
    "YABA: Recebido. Vou localizar a origem do sinal.",
    "Central: Evite confronto desnecessário. O arquivo está dentro do setor médico.",
    "YABA: Entendido. Iniciando operação."
]

func start(dialogue) -> void:
    if running: return
    running=true; timer=0; step=0
    if dialogue: dialogue.show_line("CINEMATIC", lines[0])

func tick(delta:float, dialogue) -> void:
    if not running: return
    timer += delta
    if timer >= 2.8:
        timer=0; step+=1
        if step >= lines.size():
            running=false; finished.emit()
        elif dialogue:
            dialogue.show_line("CINEMATIC", lines[step])
