class_name CityLifeDirector2074
extends Node

## City-life simulation: traffic, schedules, events and emergency response.
var event_timer:=0.0
var rng:=RandomNumberGenerator.new()
var events=[
    'Falha de energia no distrito residencial',
    'Acidente de hovercar no cruzamento',
    'Alerta policial no setor industrial',
    'Drone civil perdeu comunicação',
    'Evacuação temporária do metrô',
    'Pane em terminal urbano'
]

signal city_event(text)

func _ready(): rng.seed=2074
func tick(delta:float, player:Node3D, police:Array[Node3D]):
    event_timer-=delta
    if event_timer<=0 and player:
        event_timer=rng.randf_range(25.0,55.0)
        var text=events[rng.randi_range(0,events.size()-1)]
        city_event.emit(text)
        for p in police:
            if is_instance_valid(p): p.set_meta('dispatch_target',player.global_position)
