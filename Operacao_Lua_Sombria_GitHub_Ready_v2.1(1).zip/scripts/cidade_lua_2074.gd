class_name CidadeLua2074
extends Node3D

var world_builder
var rng:=RandomNumberGenerator.new()
var traffic_points:Array[Vector3]=[]
var interactables:Array[Node3D]=[]

func build(parent:Node3D, builder):
    world_builder=builder
    rng.seed=20742074
    _district_roads(parent)
    _landmarks(parent)
    _street_furniture(parent)
    _traffic_nodes(parent)
    _spawn_city_interactables(parent)
    _spawn_interior_doors(parent)
    _spawn_detailed_props(parent)

func _district_roads(parent):
    for x in [-84,-56,-28,0,28,56,84]:
        _road(parent,Vector3(x,.06,0),Vector3(6,.1,220))
    for z in [-84,-56,-28,0,28,56,84]:
        _road(parent,Vector3(0,.06,z),Vector3(220,.1,6))
    for x in range(-3,4):
        for z in range(-3,4):
            if (abs(x)+abs(z))%2==0:
                _crossing(parent,Vector3(x*28,.11,z*28))

func _road(parent,pos,size):
    var m=MeshInstance3D.new(); var b=BoxMesh.new(); b.size=size; b.material=_mat(Color(.028,.035,.045)); m.mesh=b; m.position=pos; parent.add_child(m)

func _crossing(parent,pos):
    for i in range(-4,5):
        var m=MeshInstance3D.new(); var b=BoxMesh.new(); b.size=Vector3(.55,.03,5); b.material=_mat(Color(.72,.78,.82)); m.mesh=b; m.position=pos+Vector3(i*1.2,.03,0); parent.add_child(m)

func _landmarks(parent):
    var list=[
        ["res://assets/models/cidade_lua/police_hq_2074.glb",Vector3(62,0,-48),"PoliceHQ",2],
        ["res://assets/models/cidade_lua/hospital_2074.glb",Vector3(-62,0,48),"Hospital",2],
        ["res://assets/models/cidade_lua/garage_2074.glb",Vector3(62,0,48),"Garage",1],
        ["res://assets/models/cidade_lua/shop_arcade_2074.glb",Vector3(0,0,0),"Shop",0],
        ["res://assets/models/cidade_lua/metro_station_2074.glb",Vector3(0,0,72),"Metro",0],
        ["res://assets/models/cidade_lua/tower_residential_2074.glb",Vector3(-62,0,-48),"Residential",0],
    ]
    for item in list:
        var path=item[0]
        if ResourceLoader.exists(path):
            var inst=load(path).instantiate(); inst.position=item[1]; inst.name=item[2]; inst.set_meta("access_level",item[3]); parent.add_child(inst)

func _street_furniture(parent):
    for x in range(-5,6):
        for z in range(-5,6):
            if abs(x)+abs(z)%2==0:
                var lamp=MeshInstance3D.new(); var c=CylinderMesh.new(); c.top_radius=.06; c.bottom_radius=.1; c.height=3.5; c.material=_mat(Color(.08,.1,.12)); lamp.mesh=c; lamp.position=Vector3(x*20,1.75,z*20); parent.add_child(lamp)
                var glow=OmniLight3D.new(); glow.light_color=Color(.05,.55,.75); glow.light_energy=.45; glow.omni_range=5; glow.position=Vector3(0,1.7,0); lamp.add_child(glow)

func _traffic_nodes(parent):
    for x in [-84,-56,-28,0,28,56,84]: traffic_points.append(Vector3(x,.2,-100))

func _spawn_city_interactables(parent)
    _spawn_interior_doors(parent)
    _spawn_detailed_props(parent):
    for spec in [["Delegacia",Vector3(62,1,-37),2],["Hospital",Vector3(-62,1,37),2],["Garagem",Vector3(62,1,37),1],["Loja",Vector3(0,1,-8),0],["Metrô",Vector3(0,1,64),0]]:
        var a=Area3D.new(); a.name="Interacao_"+spec[0]; a.position=spec[1]; a.set_meta("access_level",spec[2]); a.set_meta("label",spec[0]); a.add_to_group("access_point"); var cs=CollisionShape3D.new(); var sh=SphereShape3D.new(); sh.radius=3; cs.shape=sh; a.add_child(cs); parent.add_child(a); interactables.append(a)

func _spawn_interior_doors(parent):
    var specs=[
        ['Apartamento',Vector3(-62,1,-43),Vector3(-62,1, -40)],
        ['Delegacia',Vector3(62,1,-43),Vector3(62,1,-40)],
        ['Hospital',Vector3(-62,1,43),Vector3(-62,1,40)],
        ['Garagem',Vector3(62,1,43),Vector3(62,1,40)],
        ['Metrô',Vector3(0,1,68),Vector3(0,-8,68)]
    ]
    for spec in specs:
        var d=Area3D.new(); d.name='Door_'+str(spec[0]); d.position=spec[1]; d.add_to_group('interior_door'); d.set_meta('interior_position',spec[2]); d.set_meta('interior_name',spec[0]); var cs=CollisionShape3D.new(); var sh=SphereShape3D.new(); sh.radius=2.4; cs.shape=sh; d.add_child(cs); parent.add_child(d)

func _spawn_detailed_props(parent):
    var props=[
        ['res://assets/models/cidade_lua/traffic_light_2074.glb',Vector3(12,0,-12)],
        ['res://assets/models/cidade_lua/street_terminal_2074.glb',Vector3(-12,0,12)],
        ['res://assets/models/cidade_lua/street_drone_port_2074.glb',Vector3(36,0,-12)],
        ['res://assets/models/cidade_lua/neon_billboard_2074.glb',Vector3(-36,0,-12)]
    ]
    for p in props:
        if ResourceLoader.exists(p[0]):
            var n=load(p[0]).instantiate(); n.position=p[1]; parent.add_child(n)

func _mat(c:Color)->StandardMaterial3D:
    var m=StandardMaterial3D.new(); m.albedo_color=c; m.roughness=.78; return m
