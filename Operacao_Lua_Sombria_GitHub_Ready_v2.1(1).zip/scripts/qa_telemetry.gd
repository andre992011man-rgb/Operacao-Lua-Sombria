class_name QATelemetry
extends Node

var frame_samples:Array[float] = []
var max_samples := 180
var warnings:Array[String] = []

func sample(delta:float, active_nodes:int) -> void:
    if delta <= 0.0: return
    frame_samples.append(delta * 1000.0)
    if frame_samples.size() > max_samples: frame_samples.pop_front()
    if active_nodes > 500: _warn("Mais de 500 nodes ativos: revisar streaming/LOD.")
    if delta > 0.066: _warn("Frame acima de 66 ms: queda abaixo de 15 FPS detectada.")

func _warn(message:String) -> void:
    if warnings.is_empty() or warnings.back() != message:
        warnings.append(message)
        if warnings.size() > 20: warnings.pop_front()

func report() -> Dictionary:
    var avg := 0.0
    for v in frame_samples: avg += v
    if not frame_samples.is_empty(): avg /= frame_samples.size()
    return {"samples":frame_samples.size(),"avg_frame_ms":avg,"warnings":warnings.duplicate()}
