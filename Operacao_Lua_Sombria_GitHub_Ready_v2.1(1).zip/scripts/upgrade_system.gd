class_name UpgradeSystem
extends Node

const COSTS := {"armor":180,"scanner":220,"engine":260,"battery":240,"storage":200}
const MAX_LEVEL := 5

func upgrade(state:GameState, module:String) -> bool:
    if not state or not COSTS.has(module): return false
    var level:int = int(state.upgrades.get(module,1))
    if level >= MAX_LEVEL: return false
    var cost:int = int(COSTS[module]) * level
    if state.credits < cost: return false
    state.credits -= cost
    state.upgrades[module] = level + 1
    state.save_game()
    return true
