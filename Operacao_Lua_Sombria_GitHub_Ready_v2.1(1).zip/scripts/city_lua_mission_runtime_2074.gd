class_name CityLuaMissionRuntime2074
extends Node

const MISSIONS := [
 {"id":1,"title":"Primeiro Sinal","objectives":["Sair do ponto seguro","Investigar o marcador","Examinar o dispositivo","Retornar ao ponto seguro"]},
 {"id":2,"title":"A Mensagem","objectives":["Localizar o informante","Conversar com o informante","Recuperar o pacote","Escapar da perseguição","Entregar o pacote"]},
 {"id":3,"title":"Rua Escura","objectives":["Entrar no depósito","Desativar duas sentinelas","Recuperar o arquivo","Sair do depósito","Entregar o arquivo"]},
 {"id":4,"title":"Cartão Cinza","objectives":["Ir à delegacia","Validar credencial","Acessar o terminal policial","Baixar a autorização"]},
 {"id":5,"title":"Paciente 17","objectives":["Entrar no hospital","Localizar o paciente","Escanear o prontuário","Encontrar a saída"]},
 {"id":6,"title":"Garagem 9","objectives":["Ir à garagem","Testar o veículo","Instalar upgrade","Sair do setor"]},
 {"id":7,"title":"Apagão","objectives":["Ir ao setor industrial","Encontrar o gerador","Restaurar energia","Investigar o terminal"]},
 {"id":8,"title":"Linha Fantasma","objectives":["Entrar no metrô","Seguir a linha","Rastrear o sinal","Sair da estação"]},
 {"id":9,"title":"Cerco","objectives":["Defender o ponto","Neutralizar a ameaça","Resgatar o civil","Alcançar o veículo"]},
 {"id":10,"title":"O Arquivo Lua","objectives":["Acessar o setor restrito","Usar o cartão militar","Baixar o arquivo","Escapar do complexo"]}
]

var state
var dialogue
var current := 0
var objective := 0

func setup(s,d): state=s; dialogue=d
func start(index:int):
    current=clamp(index,1,MISSIONS.size()); objective=0
    if dialogue: dialogue.show_line("MISSÃO", MISSIONS[current-1].title+" — "+MISSIONS[current-1].objectives[0])
func advance()->bool:
    if current<1 or current>MISSIONS.size(): return true
    objective += 1
    if objective >= MISSIONS[current-1].objectives.size():
        if dialogue: dialogue.show_line("MISSÃO", "Objetivos concluídos: "+MISSIONS[current-1].title)
        return true
    if dialogue: dialogue.show_line("OBJETIVO", MISSIONS[current-1].objectives[objective])
    return false
func objective_text()->String:
    if current<1 or current>MISSIONS.size(): return "Exploração livre"
    return MISSIONS[current-1].objectives[objective]
