class_name InteriorManager2074
extends Node3D

signal entered(name)
signal exited(name)
var active := false
var current_name := ""
var return_position := Vector3.ZERO
var player:Node3D
var root:Node3D

func setup(p:Node3D, world_root:Node3D) -> void:
    player=p; root=world_root

func enter(name:String, interior_position:Vector3) -> void:
    if not player or active: return
    return_position = player.global_position
    current_name = name
    active = true
    player.global_position = interior_position
    entered.emit(name)

func exit() -> void:
    if not player or not active: return
    player.global_position = return_position
    active = false
    exited.emit(current_name)
    current_name = ""
