class_name EnemyCombatAI2074
extends Node

signal state_changed(enemy, state)
signal request_reinforcements(enemy)

enum State { PATROL, ALERT, SEEK_COVER, FLANK, ENGAGE, RELOAD, SEARCH, PURSUIT, DOWN }
var state=State.PATROL
var enemy:CharacterBody3D
var target:Node3D
var cover_points:Array[Node3D]=[]
var last_seen:=Vector3.ZERO
var health:=100
var ammo:=12
var timer:=0.0
var squad:Array[Node3D]=[]
var reinforcements_called:=false

func setup(e:CharacterBody3D, t:Node3D, squad_members:Array[Node3D]=[]) -> void:
    enemy=e; target=t; squad=squad_members

func tick(delta:float) -> void:
    if not enemy or not target: return
    timer=max(0.0,timer-delta)
    var d=enemy.global_position.distance_to(target.global_position)
    var sees=d<28.0
    if health<=0: state=State.DOWN; return
    if sees: last_seen=target.global_position
    if ammo<=0 and state not in [State.RELOAD,State.DOWN]: state=State.RELOAD; timer=1.0
    if state==State.RELOAD:
        if timer<=0: ammo=12; state=State.ENGAGE
        return
    if d<8.0:
        state=State.ENGAGE
    elif sees and d<20.0:
        state=State.SEEK_COVER if int(Time.get_ticks_msec()/800)%2==0 else State.FLANK
    elif sees:
        state=State.PURSUIT
    else:
        state=State.SEARCH
    if state in [State.FLANK,State.PURSUIT]:
        _move_toward(last_seen + _flank_offset())
    elif state==State.SEEK_COVER:
        _move_toward(_find_cover())
    elif state==State.SEARCH:
        _move_toward(last_seen)
    elif state==State.ENGAGE:
        enemy.velocity=Vector3.ZERO
        if timer<=0 and ammo>0:
            ammo-=1; timer=0.45
    if not reinforcements_called and d<18.0:
        reinforcements_called=true; request_reinforcements.emit(enemy)

func _move_toward(p:Vector3):
    var dir=(p-enemy.global_position); dir.y=0
    if dir.length()>1.5:
        dir=dir.normalized(); enemy.velocity=dir*2.6; enemy.look_at(enemy.global_position+dir,Vector3.UP); enemy.move_and_slide()
    else: enemy.velocity=Vector3.ZERO

func _flank_offset()->Vector3:
    var side=1.0 if enemy.get_instance_id()%2==0 else -1.0
    return Vector3(side*6.0,0,3.0)

func _find_cover()->Vector3:
    if cover_points.size()>0:
        var best=cover_points[0]; var bd=enemy.global_position.distance_to(best.global_position)
        for p in cover_points:
            var dd=enemy.global_position.distance_to(p.global_position)
            if dd<bd: best=p; bd=dd
        return best.global_position
    return enemy.global_position - enemy.global_transform.basis.z*5.0

func apply_damage_zone(damage:int, zone:String) -> void:
    var mult=1.0
    if zone=='head': mult=2.0
    elif zone=='torso': mult=1.0
    elif zone=='limb': mult=.55
    health=max(0,health-int(damage*mult))
    enemy.set_meta('hp',health)
    if health<=0: state=State.DOWN
