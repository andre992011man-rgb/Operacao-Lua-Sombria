class_name SectorStreaming2074
extends Node

var registered:Array[Node3D] = []
var loaded_distance := 70.0

func register_node(n:Node3D) -> void:
    if n and not registered.has(n): registered.append(n)

func set_distance(distance:float) -> void:
    loaded_distance = clamp(distance, 30.0, 110.0)

func tick(player:Node3D) -> void:
    if not player: return
    for n in registered:
        if not is_instance_valid(n): continue
        n.visible = n.global_position.distance_to(player.global_position) <= loaded_distance
