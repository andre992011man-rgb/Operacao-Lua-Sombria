class_name CombatSystem2074
extends Node

signal hit_confirmed(target, damage)
signal ammo_changed(value)

var cooldown := 0.0
var fire_interval := 0.16
var damage := 28
var range_m := 65.0

func tick(delta: float) -> void:
    cooldown = max(0.0, cooldown - delta)

func fire(owner: Node3D, enemies: Array, ammo: int) -> int:
    if cooldown > 0.0 or ammo <= 0 or not owner: return ammo
    cooldown = fire_interval
    var origin := owner.global_position + Vector3.UP * 1.15
    var direction := -owner.global_transform.basis.z
    var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * range_m)
    query.exclude = [owner]
    var hit := owner.get_world_3d().direct_space_state.intersect_ray(query)
    if hit and hit.collider in enemies:
        var target = hit.collider
        if target.has_method("apply_damage"):
            target.apply_damage(damage)
        else:
            target.set_meta("hp", max(0, int(target.get_meta("hp", 100)) - damage))
            if int(target.get_meta("hp", 0)) <= 0:
                target.queue_free()
        hit_confirmed.emit(target, damage)
    ammo_changed.emit(ammo - 1)
    return ammo - 1
