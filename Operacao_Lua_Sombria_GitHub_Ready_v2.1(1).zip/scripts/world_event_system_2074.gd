class_name WorldEventSystem2074
extends Node
signal event_started(title:String)
var state=null
var events=[]
var timer:=0.0
var active_event=''
func setup(game_state):
    state=game_state
    var f=FileAccess.open('res://data/dynamic_events_2074.json',FileAccess.READ)
    if f:
        var d=JSON.parse_string(f.get_as_text()); f.close()
        if typeof(d)==TYPE_DICTIONARY: events=d.get('events',[])
func tick(delta,player):
    if not state:return
    timer+=delta
    if timer<45.0:return
    timer=0.0
    if events.is_empty():return
    var idx=int(Time.get_ticks_msec()/1000)%events.size()
    var e=events[idx]
    if str(e.get('world',''))==state.current_world or str(e.get('world',''))=='*':
        active_event=str(e.get('id','event')); event_started.emit(str(e.get('title','Evento 2074')))
