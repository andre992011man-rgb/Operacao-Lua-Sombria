class_name IntroCinematic2074
extends Node

var playing:=false
var t:=0.0
var lines=["Cidade Lua, 2074.","A cidade nunca dorme.","Mas esta noite, alguém abriu uma porta que deveria permanecer fechada.","YABA, sua missão começa agora."]
var label:Label

func start(parent:Node, layer:CanvasLayer):
    if playing: return
    playing=true; t=0.0
    label=Label.new(); label.position=Vector2(90,500); label.size=Vector2(1100,100); label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; label.add_theme_font_size_override("font_size",26); layer.add_child(label)
    set_process(true)

func _process(delta):
    if not playing: return
    t+=delta
    var idx=min(int(t/2.8),lines.size()-1); label.text=lines[idx]
    if t>11.5:
        playing=false; if is_instance_valid(label): label.queue_free(); set_process(false)
