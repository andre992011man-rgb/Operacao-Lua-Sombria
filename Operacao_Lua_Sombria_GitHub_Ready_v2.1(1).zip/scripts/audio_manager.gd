extends Node
class_name AudioManager
func play_ui(): pass
func play_shot(): pass
func play_damage(): pass
