class_name CraftingSystem2074
extends Node
signal crafted(recipe_id:String)
var recipes={}
var state=null
func setup(game_state):
    state=game_state
    var f=FileAccess.open('res://data/crafting_recipes_2074.json',FileAccess.READ)
    if f:
        var d=JSON.parse_string(f.get_as_text()); f.close()
        if typeof(d)==TYPE_DICTIONARY: recipes=d.get('recipes',{})
func can_craft(id:String)->bool:
    if not recipes.has(id) or not state:return false
    for k in recipes[id].get('cost',{}):
        if int(state.inventory.get(k,0))<int(recipes[id]['cost'][k]):return false
    return true
func craft(id:String)->bool:
    if not can_craft(id):return false
    var r=recipes[id]
    for k in r.get('cost',{}): state.inventory[k]=int(state.inventory.get(k,0))-int(r['cost'][k])
    for k in r.get('result',{}): state.inventory[k]=int(state.inventory.get(k,0))+int(r['result'][k])
    crafted.emit(id); state.save_game(); return true
