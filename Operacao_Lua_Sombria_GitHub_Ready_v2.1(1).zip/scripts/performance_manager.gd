class_name PerformanceManager
extends Node
signal quality_changed(level:int)
var quality:=2
var target_fps:=30
var frame_time_accum:=0.0
var frame_count:=0
var mobile_mode:=true

func _ready():
    Engine.max_fps=30
    if OS.has_feature("mobile"): mobile_mode=true

func _process(delta):
    frame_time_accum+=delta; frame_count+=1
    if frame_time_accum>=2.0:
        var fps=float(frame_count)/frame_time_accum
        var old=quality
        if fps<24 and quality>0: quality-=1
        elif fps>34 and quality<2: quality+=1
        if old!=quality: quality_changed.emit(quality)
        frame_time_accum=0; frame_count=0

func shadow_distance()->float:
    return [28.0,45.0,65.0][quality]

func actor_distance()->float:
    return [28.0,42.0,55.0][quality]
