class_name PoliceAI2074
extends Node

signal alert_level_changed(level)
var alert_level := 0
var suspects:Array[Node3D] = []
var cooldown := 0.0

func tick(delta:float, player:Node3D, police:Array[Node3D]) -> void:
    cooldown = max(0.0, cooldown-delta)
    if not player: return
    var observed := false
    for p in police:
        if not is_instance_valid(p): continue
        var d := p.global_position.distance_to(player.global_position)
        if d < 18.0:
            observed = true
            p.set_meta("state", "pursuit")
            var dir := (player.global_position-p.global_position).normalized()
            p.velocity = dir * 2.8
            if p is CharacterBody3D: p.move_and_slide()
    if observed and cooldown <= 0:
        alert_level = min(5, alert_level+1)
        cooldown = 4.0
        alert_level_changed.emit(alert_level)
    elif not observed and cooldown <= 0:
        alert_level = max(0, alert_level-1)
        cooldown = 7.0
        alert_level_changed.emit(alert_level)
