extends Node
class_name InventorySystem
var items:Dictionary={"municao":30,"kit_medico":2,"credito":1000,"evidencia":0,"combustivel":100}
func add_item(id:String,amount:int=1): items[id]=int(items.get(id,0))+amount
func remove_item(id:String,amount:int=1)->bool:
    if int(items.get(id,0))<amount:return false
    items[id]-=amount; return true
