class_name NPCRoutineSystem
extends Node

var schedules:Dictionary = {}
var rng := RandomNumberGenerator.new()

func register(npc:Node3D, home:Vector3, work:Vector3, shop:Vector3) -> void:
    if not npc: return
    schedules[npc.get_instance_id()] = {"npc":npc,"home":home,"work":work,"shop":shop,"phase":rng.randi_range(0,2)}

func unregister(npc:Node3D) -> void:
    if npc: schedules.erase(npc.get_instance_id())

func tick(hour:float, delta:float, player:Node3D, max_distance:float = 60.0) -> void:
    if not player: return
    var target_phase := 0
    if hour >= 7.0 and hour < 17.0: target_phase = 1
    elif hour >= 17.0 and hour < 21.0: target_phase = 2
    for key in schedules.keys():
        var s:Dictionary = schedules[key]
        var npc:Node3D = s.get("npc")
        if not is_instance_valid(npc):
            schedules.erase(key)
            continue
        if npc.global_position.distance_to(player.global_position) > max_distance:
            continue
        var target:Vector3 = s["home"]
        if target_phase == 1: target = s["work"]
        elif target_phase == 2: target = s["shop"]
        var d:Vector3 = target - npc.global_position
        if d.length() > 1.2:
            npc.global_position += d.normalized() * delta * 1.1
