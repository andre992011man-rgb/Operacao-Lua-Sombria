extends Node
## Streams 10,000 modular 4D definitions as lightweight metadata.
## Godot rendering remains 3D; the 4th dimension is represented by temporal/state variants.
@export var shard_count:int = 100
@export var active_radius_m:float = 180.0
var cache := {}
func load_shard(shard:int)->Array:
    if cache.has(shard): return cache[shard]
    var path = "res" + "://data/modular_4d_10000/shard_%03d.json" % shard
    if not FileAccess.file_exists(path): return []
    var f=FileAccess.open(path,FileAccess.READ)
    var d=JSON.parse_string(f.get_as_text())
    var arr=d.get("objects",[]) if typeof(d)==TYPE_DICTIONARY else []
    cache[shard]=arr
    return arr
func get_object(object_id:int)->Dictionary:
    if object_id<1 or object_id>10000: return {}
    var shard=int((object_id-1)/100)+1
    for item in load_shard(shard):
        if int(str(item.get("id", "M4D-0")).trim_prefix("M4D-"))==object_id: return item
    return {}
