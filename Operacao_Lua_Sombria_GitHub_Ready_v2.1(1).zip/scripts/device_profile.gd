class_name DeviceProfile
extends Node

# Perfil adaptativo para aparelhos Android de entrada/intermediarios.
# Nao substitui teste fisico: apenas define limites seguros e escalaveis.
var quality := 1
var target_fps := 30
var internal_scale := 0.80
var max_active_civilians := 12
var max_active_hostiles := 6
var max_active_vehicles := 6
var max_effect_distance := 55.0
var thermal_level := 0

func configure_from_profile(profile:String = "Galaxy A16") -> void:
    match profile:
        "Galaxy A16":
            quality = 1
            target_fps = 30
            internal_scale = 0.78
            max_active_civilians = 12
            max_active_hostiles = 6
            max_active_vehicles = 5
            max_effect_distance = 55.0
        "Low":
            quality = 0
            target_fps = 30
            internal_scale = 0.65
            max_active_civilians = 7
            max_active_hostiles = 4
            max_active_vehicles = 3
            max_effect_distance = 42.0
        "High":
            quality = 2
            target_fps = 30
            internal_scale = 0.90
            max_active_civilians = 18
            max_active_hostiles = 8
            max_active_vehicles = 8
            max_effect_distance = 75.0

func sample_frame(frame_ms:float) -> void:
    # Histerese simples para evitar ficar alternando qualidade a cada frame.
    if frame_ms > 42.0 and quality > 0:
        quality -= 1
    elif frame_ms < 28.0 and quality < 2:
        quality += 1
