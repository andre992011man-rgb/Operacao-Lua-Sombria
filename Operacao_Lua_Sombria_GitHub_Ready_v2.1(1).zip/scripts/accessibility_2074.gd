class_name Accessibility2074
extends Node
## Camada de acessibilidade: escala de HUD, contraste, tremor e texto.
signal settings_changed
var text_scale:=1.0
var high_contrast:=false
var reduced_motion:=false
var screen_shake:=1.0
var subtitles:=true
var color_assist:=false
func apply_to_hud(root:CanvasLayer):
    if not root:return
    root.scale=Vector2(text_scale,text_scale)
func toggle_contrast(): high_contrast=not high_contrast; settings_changed.emit()
func toggle_motion(): reduced_motion=not reduced_motion; screen_shake=0.0 if reduced_motion else 1.0; settings_changed.emit()
func set_text_scale(v:float): text_scale=clamp(v,0.85,1.5); settings_changed.emit()
func to_dict(): return {'text_scale':text_scale,'high_contrast':high_contrast,'reduced_motion':reduced_motion,'subtitles':subtitles,'color_assist':color_assist}
