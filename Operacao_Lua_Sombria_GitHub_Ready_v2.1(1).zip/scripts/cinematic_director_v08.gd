class_name CinematicDirectorV08
extends Node
signal finished
var playing:=false
var elapsed:=0.0
var shot_index:=0
var shots=[]
var dialogue:Node
var camera:Camera3D
var player:Node3D
func start_intro(cam:Camera3D, actor:Node3D, dlg:Node):
    camera=cam; player=actor; dialogue=dlg
    shots=[{'t':0.0,'label':'CENTRAL: YABA, conexão estabelecida.','offset':Vector3(0,15,24)},{'t':4.0,'label':'YABA: Cidade Lua parece tranquila.','offset':Vector3(8,4,10)},{'t':8.0,'label':'CENTRAL: O sinal veio de uma zona restrita.','offset':Vector3(-8,3,8)},{'t':12.0,'label':'YABA: Então vamos descobrir quem o enviou.','offset':Vector3(0,2,6)}]
    elapsed=0; shot_index=0; playing=true
func tick(delta:float):
    if not playing or not player or not camera: return
    elapsed+=delta
    if shot_index<shots.size() and elapsed>=float(shots[shot_index].t):
        var shot=shots[shot_index]; camera.global_position=player.global_position+shot.offset; camera.look_at(player.global_position+Vector3.UP*1.1)
        if dialogue: dialogue.show_line('CINEMATIC',shot.label)
        shot_index+=1
    if elapsed>=16.0: playing=false; finished.emit()
