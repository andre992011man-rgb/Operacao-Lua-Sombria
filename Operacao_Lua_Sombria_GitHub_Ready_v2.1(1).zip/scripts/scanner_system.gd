extends Node
class_name ScannerSystem
signal scan_completed(result:String)
var active := false
var cooldown := 0.0
var energy := 100.0

func scan(player:Node3D, targets:Array[Node3D]) -> String:
    if cooldown > 0.0 or energy < 8.0: return "Scanner indisponível"
    cooldown=1.0; energy=max(0.0,energy-8.0)
    var nearest:Node3D=null; var best:=28.0
    for t in targets:
        if is_instance_valid(t):
            var d=player.global_position.distance_to(t.global_position)
            if d<best: best=d; nearest=t
    var result="Nenhuma assinatura relevante"
    if nearest: result="Assinatura detectada: %s • distância %.1fm" % [nearest.name,best]
    scan_completed.emit(result); return result

func recharge(delta:float):
    energy=min(100.0,energy+delta*2.5)
