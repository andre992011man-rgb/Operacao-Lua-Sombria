class_name CidadeLuaMissionFlow
extends Node

var state
var dialogue
var access_cards
var active_story:Array=[]

func setup(s,d,a):
    state=s; dialogue=d; access_cards=a
    var f=FileAccess.open("res://data/cidade_lua_story.json",FileAccess.READ)
    if f: active_story=JSON.parse_string(f.get_as_text())

func on_mission_start(index:int):
    if index<1 or index>active_story.size(): return
    var m=active_story[index-1]
    dialogue.show_line("YABA",m.title+" — "+str(m.objectives[0]))

func on_objective_complete(index:int):
    if index<1 or index>active_story.size(): return
    var m=active_story[index-1]
    if index==1: access_cards.grant_card(1,state)
    elif index==4: access_cards.grant_card(2,state)
    elif index==10: access_cards.grant_card(3,state)
    dialogue.show_line("Central",m.objectives[min(state.mission_objective,m.objectives.size()-1)])
