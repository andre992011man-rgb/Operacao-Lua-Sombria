class_name AccessCardSystem
extends Node

signal access_changed(level:int)
var level:int = 0
var card_names := {0:"Sem cartão",1:"Cartão Civil",2:"Cartão Policial",3:"Cartão Militar",4:"Cartão Comando"}

func setup(state):
    level = int(state.inventory.get("access_card_level", 0))

func unlock(level_required:int, state)->bool:
    if level >= level_required:
        return true
    if int(state.inventory.get("access_card_level",0)) >= level_required:
        level = int(state.inventory.get("access_card_level",0))
        return true
    return false

func grant_card(new_level:int, state)->bool:
    if new_level <= level: return false
    level = new_level
    state.inventory["access_card_level"] = level
    state.inventory["access_card_name"] = card_names.get(level, "Cartão 2074")
    state.save_game()
    access_changed.emit(level)
    return true

func card_name()->String:
    return card_names.get(level,"Cartão 2074")
