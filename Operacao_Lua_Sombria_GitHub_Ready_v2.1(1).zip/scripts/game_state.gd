class_name GameState
extends Node

const SAVE_PATH := "user://yaba_save_v3.json"
var mission_index := 0
var hp := 100.0
var credits := 500
var current_world := "Cidade Lua"
var day_time := 8.0
var weather := "clear"
var weapon_ammo := 30
var discovered := {"Cidade Lua": true}
var inventory := {"kit_medico": 2, "municao": 90, "evidencia": 0, "combustivel": 100}
var equipped_module := "scanner"
var scanner_energy := 100.0
var drone_charges := 3
var reputation := 0
var vehicle_type := "car"
var vehicle_unlocked := {"car":true,"motorcycle":true,"boat":true,"rover":true,"shuttle":true}
var upgrades := {"armor":1,"scanner":1,"engine":1,"battery":1,"storage":1}
var side_missions_completed := 0
var mission_objective := 0
var credits_2074 := 0
var access_card_level := 0

func save_game() -> void:
    var data := {"version":3,"mission":mission_index,"objective":mission_objective,"hp":hp,"credits":credits,"world":current_world,"time":day_time,"weather":weather,"ammo":weapon_ammo,"inventory":inventory,"discovered":discovered,"module":equipped_module,"scanner":scanner_energy,"drone":drone_charges,"reputation":reputation,"vehicle":vehicle_type,"vehicle_unlocked":vehicle_unlocked,"upgrades":upgrades,"side":side_missions_completed,"access_card_level":int(inventory.get("access_card_level",access_card_level)),"access_card_name":str(inventory.get("access_card_name","Sem cartão"))}
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f: f.store_string(JSON.stringify(data))

func load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH): return
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if not f: return
    var d = JSON.parse_string(f.get_as_text()); f.close()
    if typeof(d) != TYPE_DICTIONARY: return
    mission_index=int(d.get("mission",mission_index)); mission_objective=int(d.get("objective",mission_objective)); hp=float(d.get("hp",hp)); credits=int(d.get("credits",credits)); current_world=str(d.get("world",current_world)); day_time=float(d.get("time",day_time)); weather=str(d.get("weather",weather)); weapon_ammo=int(d.get("ammo",weapon_ammo)); inventory=d.get("inventory",inventory); discovered=d.get("discovered",discovered); equipped_module=str(d.get("module",equipped_module)); scanner_energy=float(d.get("scanner",scanner_energy)); drone_charges=int(d.get("drone",drone_charges)); reputation=int(d.get("reputation",reputation)); vehicle_type=str(d.get("vehicle",vehicle_type)); vehicle_unlocked=d.get("vehicle_unlocked",vehicle_unlocked); upgrades=d.get("upgrades",upgrades); side_missions_completed=int(d.get("side",side_missions_completed)); access_card_level=int(d.get("access_card_level",inventory.get("access_card_level",0))); inventory["access_card_level"]=access_card_level; inventory["access_card_name"]=str(d.get("access_card_name",inventory.get("access_card_name","Sem cartão")))
