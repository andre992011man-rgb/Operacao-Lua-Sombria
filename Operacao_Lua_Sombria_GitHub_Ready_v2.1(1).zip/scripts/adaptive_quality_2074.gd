class_name AdaptiveQuality2074
extends Node
## Ajuste adaptativo de carga para Android. Nao promete FPS: usa telemetria local para reduzir picos.
signal quality_changed(level:int)
var level:=1
var target_fps:=30
var sample_time:=0.0
var frames:=0
var accumulated_ms:=0.0
var cooldown:=0.0
func setup(device_profile):
    level=int(device_profile.quality)
    target_fps=int(device_profile.target_fps)
func tick(delta:float):
    sample_time += delta
    frames += 1
    accumulated_ms += delta*1000.0
    cooldown=max(0.0,cooldown-delta)
    if sample_time < 2.0 or cooldown>0.0:return
    var avg=accumulated_ms/float(max(1,frames))
    var old=level
    if avg>38.0 and level>0: level-=1
    elif avg<29.0 and level<2: level+=1
    if level!=old:
        cooldown=8.0; quality_changed.emit(level)
    sample_time=0.0; frames=0; accumulated_ms=0.0
func profile_name()->String:
    return ['Baixo','A16 Equilibrado','Alto'][clamp(level,0,2)]
