extends Node
class_name MissionManager

var missions:Array = []
var current_index:int = 0
var objective_index:int = 0
var completed:Array[int] = []

func load_data(path:String="res://data/missions_100_detailed.json"):
    var f=FileAccess.open(path,FileAccess.READ)
    if f:
        var parsed=JSON.parse_string(f.get_as_text())
        if parsed is Array: missions=parsed

func start(id:int):
    current_index=clamp(id-1,0,max(0,missions.size()-1)); objective_index=0

func current()->Dictionary:
    if missions.is_empty(): return {}
    return missions[current_index]

func advance()->bool:
    if missions.is_empty(): return false
    objective_index += 1
    if objective_index >= current().get("objectives",[]).size():
        completed.append(int(current().get("id",current_index+1))); objective_index=0; return true
    return false

func objective()->String:
    if missions.is_empty(): return ""
    var objs=current().get("objectives",[])
    if objective_index>=objs.size(): return "Concluída"
    return str(objs[objective_index])
