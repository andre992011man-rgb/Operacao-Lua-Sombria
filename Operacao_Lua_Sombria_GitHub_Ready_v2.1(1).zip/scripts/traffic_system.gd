class_name TrafficSystem
extends Node3D

var vehicles:Array[Node3D] = []
var routes:Array[Array] = []
var rng := RandomNumberGenerator.new()
var model_path := "res://assets/models/cidade_lua/hovercar_2074_detailed.glb"

func setup(route_count:int = 6) -> void:
    routes.clear()
    for i in range(route_count):
        var z := float((i - route_count / 2) * 18)
        routes.append([Vector3(-105,0.45,z), Vector3(105,0.45,z)])

func spawn_model_vehicle(route_index:int, speed:float = 7.0) -> Node3D:
    if routes.is_empty(): return null
    var v:=Node3D.new(); v.name="TrafficHover_2074"; add_child(v)
    var model=load(model_path).instantiate() if ResourceLoader.exists(model_path) else null
    if model: v.add_child(model)
    var route:Array=routes[route_index%routes.size()]
    v.global_position=route[0]
    v.set_meta("traffic_route",route); v.set_meta("traffic_speed",speed); v.set_meta("traffic_index",1)
    vehicles.append(v); return v

func spawn_vehicle(scene:PackedScene, route_index:int, speed:float = 7.0) -> Node3D:
    if not scene or routes.is_empty(): return null
    var v:Node3D=scene.instantiate(); add_child(v)
    var route:Array=routes[route_index%routes.size()]
    v.global_position=route[0]; v.set_meta("traffic_route",route); v.set_meta("traffic_speed",speed); v.set_meta("traffic_index",1); vehicles.append(v); return v

func clear_vehicles()->void:
    for v in vehicles:
        if is_instance_valid(v): v.queue_free()
    vehicles.clear()

func tick(delta:float, player:Node3D, max_distance:float = 80.0) -> void:
    if not player: return
    for v in vehicles:
        if not is_instance_valid(v): continue
        if v.global_position.distance_to(player.global_position) > max_distance:
            v.visible = false; continue
        v.visible = true
        var route:Array = v.get_meta("traffic_route", [])
        var idx:int = int(v.get_meta("traffic_index", 1))
        if route.size() < 2: continue
        var target:Vector3 = route[idx]
        var delta_pos:Vector3 = target - v.global_position
        if delta_pos.length() < 2.0:
            idx=(idx+1)%route.size(); v.set_meta("traffic_index",idx); continue
        v.look_at(Vector3(target.x,v.global_position.y,target.z),Vector3.UP)
        v.global_position += delta_pos.normalized() * float(v.get_meta("traffic_speed",7.0)) * delta
