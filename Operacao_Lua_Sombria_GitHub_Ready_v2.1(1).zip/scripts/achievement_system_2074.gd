class_name AchievementSystem2074
extends Node
signal unlocked(id:String,title:String)
var unlocked_ids:={}
var state=null
var defs={}
func setup(game_state):
    state=game_state
    var f=FileAccess.open('res://data/achievements_2074.json',FileAccess.READ)
    if f:
        var d=JSON.parse_string(f.get_as_text()); f.close()
        if typeof(d)==TYPE_DICTIONARY: defs=d.get('achievements',{})
func tick():
    if not state:return
    check('first_steps',state.mission_index>=1)
    check('ten_missions',state.mission_index>=10)
    check('fifty_missions',state.mission_index>=50)
    check('moon_somber',state.mission_index>=73)
    check('spacebound',state.mission_index>=78)
    check('explorer',state.discovered.size()>=10)
    check('reputation_100',state.reputation>=100)
func check(id:String,condition:bool):
    if condition and not unlocked_ids.has(id):
        unlocked_ids[id]=Time.get_unix_time_from_system()
        var d=defs.get(id,{})
        unlocked.emit(id,str(d.get('title',id)))
