class_name YABAAnimationController2074
extends Node

## Articulated runtime animation controller. It drives the named GLB parts directly.
## This is a real runtime animation layer; a future skeletal rig can replace the targets without changing gameplay calls.

enum State { IDLE, WALK, RUN, CROUCH, AIM, FIRE, RELOAD, SWAP, DAMAGE, FALL, DEAD, ENTER_VEHICLE, EXIT_VEHICLE, ZERO_G }
var state := State.IDLE
var t := 0.0
var action_t := 0.0
var root: Node3D
var parts := {}
var base_rot := {}
var alive := true

func setup(actor: Node3D) -> void:
    root = actor
    _cache_parts(actor)

func _cache_parts(n: Node):
    for c in n.get_children():
        if c is Node3D:
            var key := String(c.name)
            parts[key] = c
            base_rot[key] = c.rotation
            _cache_parts(c)

func set_state(next_state: int) -> void:
    if not alive and next_state != State.DEAD: return
    if state == next_state and action_t > 0.0: return
    state = next_state
    action_t = 0.0

func set_movement(speed: float, crouched: bool=false) -> void:
    if not alive: return
    if crouched: set_state(State.CROUCH)
    elif speed > 5.8: set_state(State.RUN)
    elif speed > 0.25: set_state(State.WALK)
    else: set_state(State.IDLE)

func aim(active: bool) -> void:
    if active: set_state(State.AIM)
    elif state == State.AIM: set_state(State.IDLE)

func fire() -> void: set_state(State.FIRE)
func reload() -> void: set_state(State.RELOAD)
func swap_weapon() -> void: set_state(State.SWAP)
func damage_reaction() -> void: set_state(State.DAMAGE)
func fall() -> void: set_state(State.FALL)
func die() -> void:
    alive=false; set_state(State.DEAD)
func enter_vehicle() -> void: set_state(State.ENTER_VEHICLE)
func exit_vehicle() -> void: set_state(State.EXIT_VEHICLE)
func zero_g() -> void: set_state(State.ZERO_G)

func _process(delta: float) -> void:
    if not root: return
    t += delta
    action_t += delta
    _reset_pose()
    match state:
        State.IDLE: _idle()
        State.WALK: _walk(1.0)
        State.RUN: _walk(1.65)
        State.CROUCH: _crouch()
        State.AIM: _aim()
        State.FIRE: _fire_pose()
        State.RELOAD: _reload()
        State.SWAP: _swap()
        State.DAMAGE: _damage()
        State.FALL: _fall()
        State.DEAD: _dead()
        State.ENTER_VEHICLE: _enter_exit(false)
        State.EXIT_VEHICLE: _enter_exit(true)
        State.ZERO_G: _zero_g()
    if action_t > _duration(state) and state in [State.FIRE,State.RELOAD,State.SWAP,State.DAMAGE,State.FALL,State.ENTER_VEHICLE,State.EXIT_VEHICLE]:
        set_state(State.IDLE)

func _reset_pose():
    for k in base_rot:
        var n=parts.get(k)
        if is_instance_valid(n): n.rotation=base_rot[k]

func _r(name: String, x: float=0, y: float=0, z: float=0):
    var n=parts.get(name)
    if is_instance_valid(n): n.rotation += Vector3(x,y,z)

func _p(name: String, x: float=0, y: float=0, z: float=0):
    var n=parts.get(name)
    if is_instance_valid(n): n.position += Vector3(x,y,z)

func _idle():
    var b=sin(t*2.0)*0.02
    _p('part_0_torso',0,b,0); _r('part_10_backpack',0,sin(t*1.4)*0.02,0)

func _walk(rate: float):
    var s=sin(t*7.0*rate); var c=sin(t*7.0*rate+PI)
    _r('part_2_legL',s*0.45,0,0); _r('part_3_legR',c*0.45,0,0)
    _r('part_6_armL',c*0.25,0,0); _r('part_7_armR',s*0.25,0,0)
    _p('part_0_torso',0,abs(s)*0.025,0)

func _crouch():
    _r('part_2_legL',0.7,0,0); _r('part_3_legR',0.7,0,0); _p('part_0_torso',0,-0.28,0); _r('part_0_torso',-0.18,0,0)

func _aim():
    _r('part_6_armL',-0.75,0,0); _r('part_7_armR',-0.82,0,0); _r('part_0_torso',0.05,0,0); _r('part_9_visor',-0.08,0,0)

func _fire_pose():
    var k=clamp(action_t/0.12,0,1); _r('part_6_armL',-0.75-k*0.15,0,0); _r('part_7_armR',-0.82-k*0.15,0,0); _r('part_0_torso',0.08*k,0,0)

func _reload():
    var k=clamp(action_t/0.7,0,1); _r('part_6_armL',-0.9+0.6*k,0,0); _r('part_7_armR',-0.6+0.45*k,0,0); _r('part_0_torso',0.12,0,0)

func _swap():
    var k=clamp(action_t/0.55,0,1); _r('part_6_armL',-0.4-0.5*k,0,0); _r('part_7_armR',-0.35-0.55*k,0,0); _r('part_0_torso',0.1*sin(k*PI),0,0)

func _damage():
    var k=sin(clamp(action_t/0.45,0,1)*PI); _r('part_0_torso',0.12,k*0.25,k*0.12); _r('part_6_armL',0.2*k,0,0)

func _fall():
    var k=clamp(action_t/0.8,0,1); _r('part_0_torso',k*1.25,0,k*0.2); _r('part_2_legL',k*0.8,0,0); _r('part_3_legR',k*0.6,0,0); _p('part_0_torso',0,-0.4*k,0)

func _dead():
    _r('part_0_torso',1.35,0,0); _r('part_2_legL',0.7,0,0); _r('part_3_legR',0.55,0,0); _r('part_6_armL',0.3,0,0); _r('part_7_armR',-0.2,0,0)

func _enter_exit(reverse: bool):
    var k=clamp(action_t/0.8,0,1); var sign=-1.0 if reverse else 1.0; _r('part_0_torso',0.1*sign,0,0.35*sign*k); _r('part_2_legL',0.5*k,0,0); _r('part_3_legR',0.35*k,0,0)

func _zero_g():
    var s=sin(t*0.8); _r('part_6_armL',s*0.2,0.1*s,0); _r('part_7_armR',-s*0.2,-0.1*s,0); _r('part_2_legL',0.15*s,0,0); _r('part_3_legR',-0.15*s,0,0)

func _duration(s: int)->float:
    match s:
        State.FIRE: return 0.18
        State.RELOAD: return 0.9
        State.SWAP: return 0.65
        State.DAMAGE: return 0.5
        State.FALL: return 0.9
        State.ENTER_VEHICLE,State.EXIT_VEHICLE: return 0.9
    return 0.0
