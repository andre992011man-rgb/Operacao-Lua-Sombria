class_name WorldBuilder
extends Node3D

var rng:=RandomNumberGenerator.new()
var active_world:="Cidade Lua"
var mission_marker:Node3D
var objective_nodes:Array[Node3D]=[]
var sector_nodes:Dictionary={}
var worlds:Dictionary={}
var player_ref:Node3D

func load_world_data():
    var f=FileAccess.open("res://data/worlds_2074.json",FileAccess.READ)
    if f: worlds=JSON.parse_string(f.get_as_text())

func build(world_name:String,mission_id:int):
    active_world=world_name; rng.seed=9001+world_name.hash()+mission_id*97
    for child in get_children(): child.queue_free()
    sector_nodes.clear(); objective_nodes.clear(); load_world_data()
    _environment(world_name); _ground(world_name); _roads(world_name); _districts(world_name); _props(world_name); _landmarks(world_name); _mission_site(mission_id)
    _create_sector_grid()

func _environment(w):
    var n=WorldEnvironment.new(); n.name="Environment"; var e=Environment.new(); e.background_mode=Environment.BG_COLOR; e.background_color=_sky(w); e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; e.ambient_light_color=Color(.55,.62,.72); e.ambient_light_energy=.8; e.tonemap_mode=Environment.TONE_MAPPER_FILMIC; e.fog_enabled=(w in ["Vênus","Titã"]); e.fog_density=.008; n.environment=e; add_child(n)
    var sun=DirectionalLight3D.new(); sun.rotation_degrees=Vector3(-55,-30,0); sun.shadow_enabled=true; sun.light_energy=1.0; sun.directional_shadow_max_distance=65; add_child(sun)

func _ground(w):
    var body=StaticBody3D.new(); var mesh=MeshInstance3D.new(); var plane=PlaneMesh.new(); plane.size=Vector2(240,240); plane.subdivide_width=8; plane.subdivide_depth=8; plane.material=_mat(_ground_color(w)); mesh.mesh=plane; body.add_child(mesh)
    var cs=CollisionShape3D.new(); var shape=BoxShape3D.new(); shape.size=Vector3(240,.2,240); cs.shape=shape; cs.position.y=-.1; body.add_child(cs); add_child(body)

func _roads(w):
    if w in ["Lua","Marte","Mercúrio","Europa","Ganimedes","Titã","Plutão"]: return
    for axis in [true,false]:
        var road=MeshInstance3D.new(); var box=BoxMesh.new(); box.size=Vector3(210,.08,9) if axis else Vector3(9,.08,210); box.material=_mat(Color(.035,.045,.055)); road.mesh=box; road.position.y=.04; add_child(road)
    for i in range(-4,5):
        var lane=MeshInstance3D.new(); var box=BoxMesh.new(); box.size=Vector3(210,.03,.12) if i==0 else Vector3(4,.03,.1); box.material=_mat(Color(.45,.48,.5)); lane.mesh=box; lane.position=Vector3(0,.09,i*2.0); add_child(lane)

func _districts(w):
    var info=worlds.get(w,{})
    var districts=info.get('districts',[])
    var cols=[Color(.10,.15,.20),Color(.14,.11,.19),Color(.11,.18,.16),Color(.18,.13,.09)]
    for i in range(min(districts.size(),8)):
        var cx=float((i%4)-1.5)*48.0; var cz=float(int(i/4)-.5)*65.0
        _district(districts[i],Vector3(cx,0,cz),cols[i%cols.size()],i)

func _district(label:String,center:Vector3,color:Color,index:int):
    var parent=Node3D.new(); parent.name="Distrito_"+label; parent.position=center; add_child(parent); sector_nodes[label]=parent
    for j in range(7):
        var b=MeshInstance3D.new(); var box=BoxMesh.new(); var h=rng.randf_range(3.0,12.0)*(1.4 if index==0 else 1.0); box.size=Vector3(rng.randf_range(4,9),h,rng.randf_range(4,9)); box.material=_mat(color.lightened(rng.randf_range(-.05,.15))); b.mesh=box; b.position=Vector3(rng.randf_range(-18,18),h/2,rng.randf_range(-22,22)); parent.add_child(b)
        if j%3==0: _smart_window_grid(parent,b.position,box.size)
    _create_interior(parent,label,Vector3(0,0,-18))
    if label.to_lower().contains('hospital'): _prop_model(parent,'hospital_facade_2074.glb',Vector3(0,0,-18))
    elif label.to_lower().contains('polic'): _prop_model(parent,'police_facade_2074.glb',Vector3(0,0,-18))
    elif label.to_lower().contains('comando') or label.to_lower().contains('militar'): _prop_model(parent,'military_gate_2074.glb',Vector3(0,0,-18))
    elif label.to_lower().contains('comercial') or label.to_lower().contains('shopping'): _prop_model(parent,'shop_kiosk_2074.glb',Vector3(0,0,-18))

func _create_interior(parent,label,pos):
    var room=Node3D.new(); room.name='Interior_'+label; room.position=pos+Vector3(0,0,-6); parent.add_child(room)
    for wall_pos in [Vector3(0,1.5,-4),Vector3(0,1.5,4),Vector3(-4,1.5,0),Vector3(4,1.5,0)]:
        var w=MeshInstance3D.new(); var box=BoxMesh.new(); box.size=Vector3(8,3,.15) if abs(wall_pos.x)<.1 else Vector3(.15,3,8); box.material=_mat(Color(.06,.08,.11)); w.mesh=box; w.position=wall_pos; room.add_child(w)
    var table=MeshInstance3D.new(); var tb=BoxMesh.new(); tb.size=Vector3(2,.1,1); tb.material=_mat(Color(.12,.14,.16)); table.mesh=tb; table.position=Vector3(0,1,-1); room.add_child(table)
    var door=Area3D.new(); door.name='InteriorDoor_'+label; door.add_to_group('interior_door'); door.position=pos; door.set_meta('interior_position',room.global_position+Vector3(0,0,2.5)); parent.add_child(door)
    var cs=CollisionShape3D.new(); var sh=SphereShape3D.new(); sh.radius=1.5; cs.shape=sh; door.add_child(cs)

func _smart_window_grid(parent,pos,size):
    var count=int(clamp(size.x/1.5,2,5))
    for k in range(count):
        var w=MeshInstance3D.new(); var box=BoxMesh.new(); box.size=Vector3(.65,.22,.05); box.material=_mat(Color(.04,.3,.45),true); w.mesh=box; w.position=pos+Vector3(-size.x/2+.8+k*1.4,1.2,-size.z/2-.03); parent.add_child(w)

func _prop_model(parent,file,pos):
    var p='res://assets/models/'+file
    if ResourceLoader.exists(p):
        var sc=load(p); var inst=Node3D.new(); inst.set_script(null); parent.add_child(inst); var model=sc.instantiate(); inst.add_child(model); inst.position=pos

func _props(w):
    for i in range(90):
        var p=MeshInstance3D.new(); var cyl=CylinderMesh.new(); cyl.top_radius=.18; cyl.bottom_radius=.32; cyl.height=rng.randf_range(1,3); cyl.material=_mat(Color(.08,.16,.12)); p.mesh=cyl; p.position=Vector3(rng.randf_range(-105,105),cyl.height/2,rng.randf_range(-105,105)); add_child(p)
    if w in ['Cidade Lua','Cidade Nova','Centro Espacial','Órbita','Lua','Marte']:
        for i in range(12):
            var b=MeshInstance3D.new(); var box=BoxMesh.new(); box.size=Vector3(.15,3.5,.15); box.material=_mat(Color(.0,.55,.8),true); b.mesh=box; b.position=Vector3(rng.randf_range(-95,95),1.75,rng.randf_range(-95,95)); add_child(b)

func _landmarks(w):
    var points=[Vector3(-55,0,-55),Vector3(55,0,-55),Vector3(-55,0,55),Vector3(55,0,55)]
    for i in range(4):
        var h=MeshInstance3D.new(); var c=CylinderMesh.new(); c.top_radius=.5; c.bottom_radius=1.1; c.height=8; c.material=_mat(Color(.08,.12,.16)); h.mesh=c; h.position=points[i]+Vector3(0,4,0); add_child(h)
        var light=MeshInstance3D.new(); var s=SphereMesh.new(); s.radius=.22; s.height=.44; s.material=_mat(Color(.0,.8,1.0),true); light.mesh=s; light.position=points[i]+Vector3(0,8.3,0); add_child(light)

func _mission_site(id):
    mission_marker=MeshInstance3D.new(); var cyl=CylinderMesh.new(); cyl.top_radius=1.3; cyl.bottom_radius=1.3; cyl.height=.18; cyl.material=_mat(Color(1,.62,.04),true); mission_marker.mesh=cyl; mission_marker.position=Vector3(0,.12,-18); mission_marker.name='MissionObjective'; add_child(mission_marker); objective_nodes.append(mission_marker)

func _create_sector_grid():
    for x in range(-2,3):
        for z in range(-2,3):
            var s=Node3D.new(); s.name='Sector_%d_%d'%[x,z]; s.position=Vector3(x*48,0,z*48); s.set_meta('stream_radius',55.0); add_child(s); sector_nodes[s.name]=s

func update_streaming(player:Node3D,quality:int):
    if not player: return
    var radius=[42.0,62.0,82.0][clamp(quality,0,2)]
    for key in sector_nodes:
        var n=sector_nodes[key]
        if is_instance_valid(n) and n.name.begins_with('Sector_'):
            n.visible=n.global_position.distance_to(player.global_position)<radius+50

func _mat(c:Color,emission:=false)->StandardMaterial3D:
    var m=StandardMaterial3D.new(); m.albedo_color=c; m.roughness=.88
    if emission: m.emission_enabled=true; m.emission=c; m.emission_energy_multiplier=1.7
    return m
func _sky(w):
    if w in ['Lua','Europa','Ganimedes','Tritão','Plutão']: return Color(.008,.015,.035)
    if w in ['Marte']: return Color(.24,.07,.025)
    if w in ['Vênus','Titã','Mercúrio']: return Color(.24,.12,.035)
    return Color(.015,.045,.085)
func _ground_color(w):
    var i=worlds.get(w,{})
    var a=i.get('ground',[.09,.18,.11]); return Color(a[0],a[1],a[2])
