class_name CompletionDirectorV10
extends Node
## Orquestra sistemas de qualidade e acompanha a matriz de entrega v1.0.
signal message(text:String)
var state=null
var achievements:AchievementSystem2074
var crafting:CraftingSystem2074
var adaptive:AdaptiveQuality2074
var accessibility:Accessibility2074
var photo:PhotoMode2074
var events:WorldEventSystem2074
var last_mission=-1
func setup(game_state,camera,hud):
    state=game_state
    achievements=AchievementSystem2074.new(); add_child(achievements); achievements.setup(state); achievements.unlocked.connect(func(_id,title): message.emit('Conquista: '+title))
    crafting=CraftingSystem2074.new(); add_child(crafting); crafting.setup(state)
    adaptive=AdaptiveQuality2074.new(); add_child(adaptive); adaptive.setup(_profile())
    adaptive.quality_changed.connect(func(level): message.emit('Qualidade adaptativa: '+adaptive.profile_name()))
    accessibility=Accessibility2074.new(); add_child(accessibility); accessibility.apply_to_hud(hud)
    photo=PhotoMode2074.new(); add_child(photo); photo.setup(camera)
    events=WorldEventSystem2074.new(); add_child(events); events.setup(state); events.event_started.connect(func(title): message.emit('Evento dinâmico: '+title))
func _profile():
    var p=DeviceProfile.new(); add_child(p); p.configure_from_profile('Galaxy A16'); return p
func tick(delta,player):
    adaptive.tick(delta); events.tick(delta,player); photo.tick(delta)
    if state and state.mission_index!=last_mission:
        last_mission=state.mission_index; achievements.tick()
