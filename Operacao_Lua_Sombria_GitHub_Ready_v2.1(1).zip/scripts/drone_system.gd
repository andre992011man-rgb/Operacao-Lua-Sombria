extends Node3D
class_name DroneSystem
var deployed:=false
var target_position:=Vector3.ZERO
var speed:=8.0
var battery:=100.0

func deploy(origin:Vector3):
    global_position=origin+Vector3(0,2,-1.5); deployed=true; battery=100.0

func recall(): deployed=false

func _process(delta):
    if not deployed: return
    global_position=global_position.lerp(target_position+Vector3(0,4,0),delta*2.2)
    battery=max(0.0,battery-delta*1.5)
    if battery<=0: deployed=false
