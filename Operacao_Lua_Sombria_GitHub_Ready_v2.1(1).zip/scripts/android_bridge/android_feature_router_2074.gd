class_name AndroidFeatureRouter2074
extends Node

## Safe Android feature router for Operação Lua Sombria.
## Uses only APIs exposed by our own plugin; never stores credentials, tokens or keys.

signal event_emitted(name: String, payload: Dictionary)

var plugin: Object = null

func _ready() -> void:
    if Engine.has_singleton("LuaSombriaAndroid"):
        plugin = Engine.get_singleton("LuaSombriaAndroid")

func is_available() -> bool:
    return plugin != null

func emit_game_event(name: String, payload: Dictionary = {}) -> void:
    if plugin and plugin.has_method("emitGameEvent"):
        plugin.emitGameEvent(name, JSON.stringify(payload))
    event_emitted.emit(name, payload)

func show_notice(title: String, message: String) -> void:
    if plugin and plugin.has_method("showNotice"):
        plugin.showNotice(title, message)

func request_notifications() -> bool:
    if plugin and plugin.has_method("requestNotifications"):
        return bool(plugin.requestNotifications())
    return false

func get_runtime_snapshot() -> Dictionary:
    if plugin and plugin.has_method("getRuntimeSnapshot"):
        var raw := str(plugin.getRuntimeSnapshot())
        var parsed = JSON.parse_string(raw)
        return parsed if parsed is Dictionary else {}
    return {}
