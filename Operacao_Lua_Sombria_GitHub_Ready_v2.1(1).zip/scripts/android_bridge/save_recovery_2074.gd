class_name SaveRecovery2074
extends Node

const SLOT_ROOT := "user://save_slots/"

func _ready() -> void:
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(SLOT_ROOT))

func write_snapshot(slot:String, data:Dictionary) -> bool:
    var safe:=slot.replace("/","_").replace("\\","_")
    var tmp:=SLOT_ROOT+safe+".tmp"
    var dst:=SLOT_ROOT+safe+".json"
    var f:=FileAccess.open(tmp,FileAccess.WRITE)
    if not f: return false
    f.store_string(JSON.stringify(data)); f.flush(); f.close()
    if FileAccess.file_exists(dst): DirAccess.remove_absolute(ProjectSettings.globalize_path(dst))
    return DirAccess.rename_absolute(ProjectSettings.globalize_path(tmp),ProjectSettings.globalize_path(dst)) == OK

func read_snapshot(slot:String) -> Dictionary:
    var safe:=slot.replace("/","_").replace("\\","_")
    var p:=SLOT_ROOT+safe+".json"
    if not FileAccess.file_exists(p): return {}
    var f:=FileAccess.open(p,FileAccess.READ)
    if not f: return {}
    var d=JSON.parse_string(f.get_as_text()); f.close()
    return d if typeof(d)==TYPE_DICTIONARY else {}
