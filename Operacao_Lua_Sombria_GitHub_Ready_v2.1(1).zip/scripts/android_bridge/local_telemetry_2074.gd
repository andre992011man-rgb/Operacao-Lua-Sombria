class_name LocalTelemetry2074
extends Node

## Telemetria local para depuração e estabilidade; não envia dados para terceiros.

var events:Array[Dictionary] = []
var counters:Dictionary = {}

func event(name:String, data:Dictionary = {}) -> void:
    events.push_back({"name": name, "data": data, "time": Time.get_unix_time_from_system()})
    if events.size() > 200:
        events.pop_front()

func count(name:String) -> void:
    counters[name] = int(counters.get(name, 0)) + 1

func crash_like_report(context:String, message:String) -> void:
    event("runtime_error", {"context": context, "message": message})

func snapshot() -> Dictionary:
    return {"events": events.duplicate(true), "counters": counters.duplicate(true)}
