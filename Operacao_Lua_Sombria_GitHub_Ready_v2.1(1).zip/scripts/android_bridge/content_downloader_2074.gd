class_name ContentDownloader2074
extends Node

signal progress(pack_id:String, received:int, total:int)
signal finished(pack_id:String, ok:bool, message:String)

var _http:HTTPRequest
var _pack_id := ""
var _expected_sha256 := ""
var _target := ""

func _ready() -> void:
    _http = HTTPRequest.new()
    _http.download_file = ""
    add_child(_http)
    _http.request_completed.connect(_on_completed)

func download_pack(pack_id:String, url:String, expected_sha256:String="") -> void:
    if pack_id.is_empty() or url.is_empty():
        finished.emit(pack_id,false,"Pacote ou URL inválidos")
        return
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://content_cache/"))
    _pack_id = pack_id
    _expected_sha256 = expected_sha256.to_lower().strip_edges()
    _target = ProjectSettings.globalize_path("user://content_cache/" + pack_id + ".pack")
    _http.download_file = _target
    var err := _http.request(url)
    if err != OK: finished.emit(pack_id,false,"Falha ao iniciar download")

func _process(_delta:float) -> void:
    if is_instance_valid(_http) and _http.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
        var total := _http.get_body_size()
        var got := _http.get_downloaded_bytes()
        progress.emit(_pack_id,got,total)

func _on_completed(result:int, code:int, _headers:PackedStringArray, _body:PackedByteArray) -> void:
    if result != HTTPRequest.RESULT_SUCCESS or code < 200 or code >= 300:
        finished.emit(_pack_id,false,"Download HTTP falhou (%d)" % code)
        return
    if _expected_sha256.is_empty():
        finished.emit(_pack_id,true,"Pacote baixado")
        return
    var file := FileAccess.open(_target,FileAccess.READ)
    if not file:
        finished.emit(_pack_id,false,"Arquivo baixado não pôde ser lido")
        return
    var hash := file.get_sha256()
    file.close()
    if hash.to_lower() != _expected_sha256:
        DirAccess.remove_absolute(_target)
        finished.emit(_pack_id,false,"Hash SHA-256 incompatível")
        return
    finished.emit(_pack_id,true,"Pacote validado por SHA-256")
