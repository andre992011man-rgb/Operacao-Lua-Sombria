class_name AndroidDiagnostics2074
extends Node

var elapsed:=0.0
var frames:=0
var fps:=0.0
var memory_mb:=0.0
var nodes:=0

func _process(delta:float) -> void:
    elapsed += delta
    frames += 1
    if elapsed >= 1.0:
        fps = float(frames)/elapsed
        frames=0; elapsed=0.0
        memory_mb = float(OS.get_static_memory_usage())/1048576.0
        nodes = get_tree().get_node_count()

func snapshot() -> Dictionary:
    return {"platform":OS.get_name(),"fps":fps,"memory_mb":memory_mb,"nodes":nodes,"time":Time.get_unix_time_from_system()}
