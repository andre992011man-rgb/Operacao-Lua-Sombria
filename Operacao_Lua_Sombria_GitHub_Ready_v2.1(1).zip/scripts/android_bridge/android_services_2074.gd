class_name AndroidServices2074
extends Node

signal notification_requested(title:String, body:String)
signal permission_requested(permission:String)
signal install_requested(path:String)

var platform := "unknown"
var android := false
var last_event := ""

func _ready() -> void:
    platform = OS.get_name()
    android = platform == "Android"

func request_permission(permission:String) -> void:
    last_event = "permission:" + permission
    permission_requested.emit(permission)
    if android:
        # Native permission requests can be wired through a Godot Android plugin.
        # The gameplay layer remains functional when no plugin is installed.
        pass

func notify(title:String, body:String) -> void:
    last_event = "notification:" + title
    notification_requested.emit(title, body)

func open_external(url:String) -> void:
    if url.is_empty(): return
    OS.shell_open(url)
