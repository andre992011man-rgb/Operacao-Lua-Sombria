class_name ModernAndroidRuntime2074
extends Node
## Camada moderna de runtime para Android 2026.
## Faz somente integração própria: ciclo de vida, telemetria local,
## monitor de desempenho, economia de energia e ponte opcional para plugin Android.

signal performance_state_changed(state:String)
signal lifecycle_changed(state:String)

var sample_timer := 0.0
var low_fps_seconds := 0.0
var high_fps_seconds := 0.0
var performance_state := "balanced"
var last_fps := 0.0
var last_memory_mb := 0.0
var _paused := false

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_process(true)

func _process(delta:float) -> void:
    sample_timer += delta
    if sample_timer < 2.0:
        return
    sample_timer = 0.0
    last_fps = float(Engine.get_frames_per_second())
    var memory_bytes := Performance.get_monitor(Performance.MEMORY_STATIC)
    last_memory_mb = float(memory_bytes) / 1048576.0
    _update_performance(last_fps, delta)

func _update_performance(fps:float, delta:float) -> void:
    if fps > 0.0 and fps < 24.0:
        low_fps_seconds += 2.0
        high_fps_seconds = max(0.0, high_fps_seconds - delta)
    elif fps >= 29.0:
        high_fps_seconds += 2.0
        low_fps_seconds = max(0.0, low_fps_seconds - delta)
    else:
        low_fps_seconds = max(0.0, low_fps_seconds - delta)
        high_fps_seconds = max(0.0, high_fps_seconds - delta)

    if low_fps_seconds >= 6.0 and performance_state != "battery_saver":
        performance_state = "battery_saver"
        performance_state_changed.emit(performance_state)
    elif high_fps_seconds >= 10.0 and performance_state != "balanced":
        performance_state = "balanced"
        performance_state_changed.emit(performance_state)

func _notification(what:int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED:
        _paused = true
        lifecycle_changed.emit("paused")
    elif what == NOTIFICATION_APPLICATION_RESUMED:
        _paused = false
        lifecycle_changed.emit("resumed")

func is_android() -> bool:
    return OS.has_feature("android")

func android_singleton(name:String):
    if not is_android() or not Engine.has_singleton(name):
        return null
    return Engine.get_singleton(name)

func snapshot() -> Dictionary:
    return {
        "android": is_android(),
        "paused": _paused,
        "performance_state": performance_state,
        "fps": last_fps,
        "memory_mb": last_memory_mb,
        "renderer": RenderingServer.get_video_adapter_name()
    }
