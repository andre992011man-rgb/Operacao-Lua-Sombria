class_name GameSdkRuntime2074
extends Node

## Camada própria que reúne funções úteis observadas como padrões em APKs móveis:
## feature flags, notices, downloads/cache, atualização, diagnóstico e telemetria local.
## Não utiliza código, chaves, endpoints ou bibliotecas proprietárias do APK de referência.

signal ready_status(message:String)

var features:FeatureSwitch2074
var notices:NoticeCenter2074
var telemetry:LocalTelemetry2074
var downloader:ContentDownloader2074
var runtime:FinalAndroidRuntime2074

func _ready() -> void:
    features = FeatureSwitch2074.new(); add_child(features); features.load_from_file()
    notices = NoticeCenter2074.new(); add_child(notices)
    telemetry = LocalTelemetry2074.new(); add_child(telemetry)
    downloader = ContentDownloader2074.new(); add_child(downloader)
    runtime = FinalAndroidRuntime2074.new(); add_child(runtime)
    notices.notice_received.connect(func(title, _body): telemetry.event("notice", {"title": title}))
    downloader.progress_changed.connect(func(pack, progress): telemetry.event("download_progress", {"pack": pack, "progress": progress}))
    ready_status.emit("Game SDK Runtime 2074 ativo")

func boot() -> void:
    telemetry.event("boot", {"platform": OS.get_name()})
    notices.publish("Operação Lua Sombria", "Serviços móveis carregados.", "boot")

func set_feature(key:String, enabled:bool) -> void:
    features.set_enabled(key, enabled)
    telemetry.event("feature_switch", {"key": key, "enabled": enabled})

func report_error(context:String, message:String) -> void:
    telemetry.crash_like_report(context, message)

func diagnostics() -> Dictionary:
    return {"runtime": runtime.diagnostics_snapshot(), "telemetry": telemetry.snapshot()}
