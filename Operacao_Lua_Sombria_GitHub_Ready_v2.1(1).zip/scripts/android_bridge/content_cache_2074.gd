class_name ContentCache2074
extends Node

const ROOT := "user://content_cache/"
const INDEX := ROOT + "index.json"
var index:Dictionary = {}

func _ready() -> void:
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(ROOT))
    _load_index()

func _load_index() -> void:
    if not FileAccess.file_exists(INDEX): return
    var f:=FileAccess.open(INDEX,FileAccess.READ)
    if f:
        var d=JSON.parse_string(f.get_as_text())
        if typeof(d)==TYPE_DICTIONARY: index=d
        f.close()

func register_pack(pack_id:String, version:String, bytes:int=0) -> void:
    index[pack_id]={"version":version,"bytes":bytes,"updated":Time.get_unix_time_from_system()}
    _save_index()

func has_pack(pack_id:String, version:String="") -> bool:
    if not index.has(pack_id): return false
    if version.is_empty(): return true
    return str(index[pack_id].get("version","")) == version

func clear_pack(pack_id:String) -> void:
    index.erase(pack_id)
    _save_index()

func clear_all() -> void:
    index.clear()
    _save_index()

func _save_index() -> void:
    var f:=FileAccess.open(INDEX,FileAccess.WRITE)
    if f: f.store_string(JSON.stringify(index)); f.close()
