class_name FinalAndroidRuntime2074
extends Node

## Camada final de integração Android. Não depende de APIs proprietárias de terceiros.
## Funciona no editor/desktop e usa singleton Android opcional quando disponível.

signal status_changed(message:String)
signal update_ready(version:String, url:String)

const APP_ID := "com.operacaoluasombria.yaba2074"
const CURRENT_VERSION := "0.5.2074"
const CACHE_ROOT := "user://content_cache/"
const UPDATE_DIR := "user://updates/"

var android := false
var native_plugin := false
var updater:UpdateManager2074
var cache:ContentCache2074
var recovery:SaveRecovery2074
var diagnostics:AndroidDiagnostics2074

func _ready() -> void:
    android = OS.get_name() == "Android"
    native_plugin = Engine.has_singleton("LuaSombriaAndroid")
    updater = UpdateManager2074.new(); add_child(updater)
    cache = ContentCache2074.new(); add_child(cache)
    recovery = SaveRecovery2074.new(); add_child(recovery)
    diagnostics = AndroidDiagnostics2074.new(); add_child(diagnostics)
    updater.update_available.connect(_on_update_available)
    status_changed.emit("Android runtime pronto | %s | plugin=%s" % [OS.get_name(), str(native_plugin)])

func _on_update_available(version:String, url:String) -> void:
    update_ready.emit(version, url)
    status_changed.emit("Atualização disponível: " + version)

func check_updates(manifest_url:String) -> void:
    updater.check_manifest(manifest_url)

func open_store(url:String) -> void:
    if not url.is_empty(): OS.shell_open(url)

func snapshot_save(slot:String, data:Dictionary) -> bool:
    return recovery.write_snapshot(slot, data)

func restore_save(slot:String) -> Dictionary:
    return recovery.read_snapshot(slot)

func diagnostics_snapshot() -> Dictionary:
    return diagnostics.snapshot()
