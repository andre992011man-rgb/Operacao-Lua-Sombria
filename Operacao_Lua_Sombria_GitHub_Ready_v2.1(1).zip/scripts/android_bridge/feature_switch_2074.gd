class_name FeatureSwitch2074
extends Node

## Sistema próprio de feature flags inspirado em clientes Android modernos.
## Não copia lógica, código ou credenciais de terceiros.

signal switch_changed(key:String, enabled:bool)

var switches:Dictionary = {}

func load_from_file(path:String = "res://data/android/feature_switches_2074.json") -> void:
    if not FileAccess.file_exists(path):
        return
    var file := FileAccess.open(path, FileAccess.READ)
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Dictionary:
        switches = parsed.get("switches", {}).duplicate(true)

func is_enabled(key:String, default_value:bool = false) -> bool:
    if not switches.has(key):
        return default_value
    var entry = switches[key]
    if entry is Dictionary:
        return bool(entry.get("enabled", default_value))
    return bool(entry)

func set_enabled(key:String, enabled:bool) -> void:
    switches[key] = {"enabled": enabled}
    switch_changed.emit(key, enabled)
