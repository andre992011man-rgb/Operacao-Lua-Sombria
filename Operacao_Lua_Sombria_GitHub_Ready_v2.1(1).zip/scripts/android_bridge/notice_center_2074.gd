class_name NoticeCenter2074
extends Node

signal notice_received(title:String, body:String)

var notices:Array[Dictionary] = []

func publish(title:String, body:String, category:String = "system") -> void:
    var item := {"title": title, "body": body, "category": category, "time": Time.get_unix_time_from_system()}
    notices.push_front(item)
    if notices.size() > 30:
        notices.pop_back()
    notice_received.emit(title, body)

func latest(limit:int = 5) -> Array[Dictionary]:
    return notices.slice(0, min(limit, notices.size()))
