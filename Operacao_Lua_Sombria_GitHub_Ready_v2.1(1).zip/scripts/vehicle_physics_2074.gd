class_name VehiclePhysics2074
extends Node

## Lightweight vehicle simulation tuned for mobile: suspension, traction, braking, damage, fuel/energy.
var speed:=0.0
var steering:=0.0
var throttle:=0.0
var brake:=0.0
var fuel:=100.0
var integrity:=100.0
var engine_temp:=20.0
var wheel_spin:=0.0
var max_speed:=22.0
var acceleration:=11.0
var braking:=18.0
var drag:=3.0
var turn_rate:=1.6

func tick(delta:float, body:CharacterBody3D, occupied:bool) -> void:
    if not body: return
    if occupied:
        throttle=Input.get_axis('move_back','move_forward')
        steering=Input.get_axis('move_left','move_right')
        brake=1.0 if Input.is_action_pressed('brake') else 0.0
        if fuel<=0 or integrity<=0: throttle=0
        var target=throttle*max_speed
        speed=move_toward(speed,target,(acceleration if abs(throttle)>0.1 else drag)*delta)
        if brake>0: speed=move_toward(speed,0,braking*delta)
        body.rotate_y(-steering*delta*turn_rate*clamp(abs(speed)/max_speed,.2,1.0))
        body.velocity=-body.global_transform.basis.z*speed
        body.velocity.y=-1.2
        body.move_and_slide()
        wheel_spin += speed*delta*2.2
        fuel=max(0,fuel-abs(speed)*delta*0.035)
        engine_temp=clamp(engine_temp+abs(throttle)*delta*8.0- delta*3.0,20,120)
    else:
        speed=move_toward(speed,0,drag*delta)

func impact(damage:float):
    integrity=max(0,integrity-damage)
    if integrity<=0: speed=0

func repair(amount:float): integrity=min(100,integrity+amount)
func refuel(amount:float): fuel=min(100,fuel+amount)
