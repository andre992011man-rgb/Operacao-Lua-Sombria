class_name PhotoMode2074
extends Node
var active:=false
var saved_camera_transform:Transform3D
var camera:Camera3D
func setup(c:Camera3D): camera=c
func toggle():
    if not camera:return
    active=not active
    if active: saved_camera_transform=camera.global_transform
    else: camera.global_transform=saved_camera_transform
func tick(delta):
    if not active or not camera:return
    var speed=4.0*delta
    var v=Input.get_vector('move_left','move_right','move_forward','move_back')
    camera.position += Vector3(v.x,0,v.y)*speed
    if Input.is_action_pressed('run'): camera.position.y += speed
    if Input.is_action_pressed('brake'): camera.position.y -= speed
