extends CharacterBody3D
class_name VehicleController
@export var max_speed:=18.0
@export var acceleration:=14.0
@export var turn_rate:=1.8
var occupied:=false
var speed:=0.0
var vehicle_kind:="car"
var fuel:=100.0
var integrity:=100.0
var engine_temp:=20.0
var wheel_spin:=0.0
var skid:=0.0

func _physics_process(delta):
    if not occupied:
        speed=move_toward(speed,0,acceleration*delta)
        return
    var throttle=Input.get_axis('move_back','move_forward')
    var steer=Input.get_axis('move_left','move_right')
    var brake=Input.is_action_pressed('brake')
    if fuel<=0 or integrity<=0: throttle=0
    var target=throttle*max_speed
    speed=move_toward(speed,target,acceleration*delta)
    if brake: speed=move_toward(speed,0,22.0*delta)
    rotate_y(-steer*delta*turn_rate*clamp(abs(speed)/max_speed,.2,1.0))
    velocity=-global_transform.basis.z*speed
    velocity.y=-1.0
    var before=global_position
    move_and_slide()
    var moved=global_position.distance_to(before)
    if abs(speed)>4 and moved<abs(speed)*delta*.25: impact(2.0*abs(speed)*delta)
    fuel=max(0.0,fuel-abs(speed)*delta*0.04)
    engine_temp=clamp(engine_temp+abs(throttle)*delta*8.0-delta*3.5,20,120)
    wheel_spin += speed*delta*2.2

func impact(damage:float):
    integrity=max(0.0,integrity-damage)
    if integrity<=0: speed=0

func repair(amount:float): integrity=min(100.0,integrity+amount)
func refuel(amount:float): fuel=min(100.0,fuel+amount)
