class_name ShopSystem
extends Node

const CATALOG := {
    "kit_medico": {"price":80,"max":8},
    "municao": {"price":45,"max":240},
    "combustivel": {"price":60,"max":100},
    "drone_bateria": {"price":120,"max":6}
}

func buy(state:GameState, item:String, amount:int = 1) -> bool:
    if not state or not CATALOG.has(item): return false
    var entry:Dictionary = CATALOG[item]
    var cost:int = int(entry.price) * max(1, amount)
    if state.credits < cost: return false
    state.credits -= cost
    if item == "drone_bateria":
        state.drone_charges = min(int(entry.max), state.drone_charges + amount)
    else:
        var current:int = int(state.inventory.get(item,0))
        state.inventory[item] = min(int(entry.max), current + amount)
    state.save_game()
    return true
