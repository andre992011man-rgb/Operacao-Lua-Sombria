class_name SimpleVehicle
extends CharacterBody3D

var occupied := false
var driver: Node3D
var speed := 0.0
var max_speed := 13.0
var acceleration := 18.0

func _physics_process(delta: float) -> void:
    if not occupied:
        return
    var input_axis := Input.get_axis("move_back", "move_forward")
    var steer := Input.get_axis("move_left", "move_right")
    speed = move_toward(speed, input_axis * max_speed, acceleration * delta)
    rotate_y(-steer * delta * clamp(abs(speed) / 5.0, 0.2, 1.0))
    velocity = -global_transform.basis.z * speed
    velocity.y = -1.0
    move_and_slide()
