class_name CityLuaServices2074
extends Node

signal service_message(text)
var state
var shops
var upgrades

func setup(s, sh, up):
    state=s; shops=sh; upgrades=up

func use(service:String) -> void:
    if not state: return
    match service:
        "shop":
            if shops.buy(state, "municao", 1): service_message.emit("Loja: munição adquirida.")
            else: service_message.emit("Loja: créditos ou capacidade insuficientes.")
        "garage":
            if upgrades.upgrade(state, "engine"): service_message.emit("Garagem: motor atualizado.")
            else: service_message.emit("Garagem: upgrade indisponível.")
        "hospital":
            state.hp=min(100.0, state.hp+60.0); state.save_game(); service_message.emit("Hospital: atendimento concluído.")
        "metro":
            service_message.emit("Metrô: viagem rápida disponível entre setores desbloqueados.")
        "police":
            state.reputation += 1; state.save_game(); service_message.emit("Delegacia: reputação atualizada.")
