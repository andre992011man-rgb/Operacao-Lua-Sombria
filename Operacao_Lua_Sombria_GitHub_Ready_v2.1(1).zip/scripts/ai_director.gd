class_name AIDirector
extends Node

signal threat_level_changed(level:int)
var threat_level := 0
var cooldown := 0.0

func tick(delta:float, player:Node3D, enemies:Array, world:String) -> void:
    if not player: return
    cooldown = max(0.0, cooldown - delta)
    var nearest := 99999.0
    for e in enemies:
        if is_instance_valid(e): nearest = min(nearest, e.global_position.distance_to(player.global_position))
    var next_level := 0
    if nearest < 12.0: next_level = 3
    elif nearest < 28.0: next_level = 2
    elif nearest < 55.0: next_level = 1
    if next_level != threat_level and cooldown <= 0.0:
        threat_level = next_level
        cooldown = 0.5
        threat_level_changed.emit(threat_level)
