# Integração Android — Operação Lua Sombria

Esta versão incorpora funções equivalentes às capacidades técnicas observadas no APK enviado: cache de conteúdo, atualização por manifesto, snapshots de save, abstração de notificações/permissões/intents e diagnóstico de desempenho.

Não copia código proprietário, chaves, certificados ou assets de terceiros. O APK enviado foi usado apenas como referência técnica para identificar categorias de infraestrutura Android.

## Próximo passo
Exportar pelo Godot 4.7/GABE em Android e testar no Galaxy A16. O APK final ainda não é gerado por este pacote.

## v1.2 — integração ampliada
A camada foi ampliada com downloader de conteúdo e validação SHA-256, manifesto de conteúdo, runtime Android unificado e preset Gradle para exportação. O projeto continua independente de código proprietário do APK de referência.
