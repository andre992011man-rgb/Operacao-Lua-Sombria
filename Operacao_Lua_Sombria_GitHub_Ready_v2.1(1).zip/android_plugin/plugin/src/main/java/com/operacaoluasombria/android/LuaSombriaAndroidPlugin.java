package com.operacaoluasombria.android;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;
import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.GodotPlugin;
import org.godotengine.godot.plugin.UsedByGodot;
import java.util.HashSet;
import java.util.Set;

public final class LuaSombriaAndroidPlugin extends GodotPlugin {
    private final Set<String> events = new HashSet<>();
    public LuaSombriaAndroidPlugin(Godot godot) { super(godot); }
    @Override public String getPluginName() { return "LuaSombriaAndroid"; }
    @UsedByGodot public void showNotice(String title, String message) {
        Activity a = getActivity(); if (a == null) return;
        a.runOnUiThread(() -> Toast.makeText(a, title + ": " + message, Toast.LENGTH_SHORT).show());
    }
    @UsedByGodot public boolean requestNotifications() {
        Activity a = getActivity(); if (a == null || Build.VERSION.SDK_INT < 33) return true;
        if (a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return true;
        a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2074); return false;
    }
    @UsedByGodot public void emitGameEvent(String name, String payload) {
        if (name != null && !name.isEmpty()) events.add(name);
    }
    @UsedByGodot public String getRuntimeSnapshot() {
        return "{\"android_api\":" + Build.VERSION.SDK_INT + ",\"model\":\"" + escape(Build.MODEL) + "\",\"manufacturer\":\"" + escape(Build.MANUFACTURER) + "\",\"events\":" + events.size() + "}";
    }
    private static String escape(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }
}
