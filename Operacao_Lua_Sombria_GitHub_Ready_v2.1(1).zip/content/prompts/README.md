# Prompts de produção

Os prompts desta pasta servem para orientar a criação de conteúdo original/editável para YABA, veículos, cidades, planetas, inimigos, UI e cinematics.

Regra: o prompt pode ser inspirado por gêneros e referências visuais, mas o resultado incorporado ao jogo deve ser original ou ter licença que permita uso e redistribuição.
