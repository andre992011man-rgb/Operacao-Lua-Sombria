# Fontes oficiais usadas no build

- Godot 4.7.2 estável: https://godotengine.org/download/archive/4.7.2-stable/
- Godot Gradle Android: https://docs.godotengine.org/en/4.7/tutorials/export/android_gradle_build.html
- Godot Android plugins: https://docs.godotengine.org/en/4.7/tutorials/platform/android/android_plugin.html
- Android command-line tools / SDK: https://developer.android.com/tools
- Android Build Tools: https://developer.android.com/tools/releases/build-tools
- GitHub Actions: https://docs.github.com/en/actions/concepts/billing-and-usage

- Godot 4.7.2 stable archive: https://godotengine.org/download/archive/4.7.2-stable/
- Codemagic: https://codemagic.io/
- Bitrise: https://bitrise.io/
- Firebase App Distribution: https://firebase.google.com/products/app-distribution
- Google Play Console: https://play.google.com/console/


Pipeline corrigido v1.9: ajuste do diretório raiz do script cloud e handoff de artefatos para Bitrise.
